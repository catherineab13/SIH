package UI;

import NF.FichePatient;
import static UI.FonctionsDonnees.pane_popup;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;

public class AccueilPH extends javax.swing.JFrame {
    AfficherPatientPH afficherPatientPH=new AfficherPatientPH();
    
    //Page d'accueil
    FrontPage frontPageSE=new FrontPage();
    
    public AccueilPH() {
        initComponents();
        this.setExtendedState(MAXIMIZED_BOTH);
        //init de l'accueil
        fonctionnalitePH.removeAll();
        fonctionnalitePH.add(frontPageSE);
        this.setVisible(true);
        
    }
      
    void rechercherPatientPH(){
        //recuperation des informations pour la recherche
        String nom_a_rech = txt_accPH_nom.getText();
        String prenom_a_rech = txt_accPH_prenom.getText();
        String date_naissance_a_rech = txt_accPH_date_naissance.getText();
        //FORMATAGE DES INFORMATIONS RENSEIGNEES
        nom_a_rech = nom_a_rech.toUpperCase();
        prenom_a_rech = prenom_a_rech.toUpperCase();
        //SI LES INFORMATIONS SONT AU BON FORMAT
        if (FonctionsDonnees.verifFormatDonnees(nom_a_rech, prenom_a_rech, date_naissance_a_rech)){
            FichePatient pat_rech=FichePatient.rechercherPatient(nom_a_rech, prenom_a_rech, date_naissance_a_rech);
            //SI LE PATIENT EXISTE
            if(pat_rech.getNom()!=null){
                //nettoyage des champs et de la fenetre
                fonctionnalitePH.removeAll();
                txt_accPH_nom.setText("");
                txt_accPH_prenom.setText("");
                txt_accPH_date_naissance.setText("yyyy-mm-dd");
                //LOAD DE L'INTERFACE PH
                fonctionnalitePH.add(this.afficherPatientPH);
                afficherPatientPH.loadPatPH(pat_rech);
                //ON REDESSINE L'INTERFACE
                validate();
                repaint();               
            }
            else{
                pane_popup.showMessageDialog(null, "Le patient n'existe pas", "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        }      
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        barrePH = new javax.swing.JPanel();
        lbl_accPH_question = new javax.swing.JLabel();
        lbl_accPH_rechercher_patient = new javax.swing.JLabel();
        lbl_accPH_nom = new javax.swing.JLabel();
        txt_accPH_nom = new javax.swing.JTextField();
        lbl_accPH_prenom = new javax.swing.JLabel();
        txt_accPH_prenom = new javax.swing.JTextField();
        lbl_accPH_date_naissance = new javax.swing.JLabel();
        txt_accPH_date_naissance = new javax.swing.JTextField();
        but_accPH_rechercher = new javax.swing.JButton();
        lbl_accPH_ajouter_patient = new javax.swing.JLabel();
        but_accPH_ajouter = new javax.swing.JButton();
        but_accPH_deconnection = new javax.swing.JButton();
        but_accPH_accueil = new javax.swing.JButton();
        lbl_accPH_examen = new javax.swing.JLabel();
        but_accPH_examen = new javax.swing.JButton();
        lbl_accPH_compte_rendu = new javax.swing.JLabel();
        but_accPH_compte_rendu = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        fonctionnalitePH = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(1024, 768));
        setMinimumSize(new java.awt.Dimension(1024, 768));
        setPreferredSize(new java.awt.Dimension(1024, 768));

        barrePH.setBackground(new java.awt.Color(1, 95, 191));
        barrePH.setBorder(javax.swing.BorderFactory.createCompoundBorder());
        barrePH.setMaximumSize(new java.awt.Dimension(300, 768));
        barrePH.setMinimumSize(new java.awt.Dimension(300, 768));

        lbl_accPH_question.setBackground(new java.awt.Color(1, 95, 191));
        lbl_accPH_question.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        lbl_accPH_question.setForeground(new java.awt.Color(255, 255, 255));
        lbl_accPH_question.setText("Que souhaitez-vous faire ?");

        lbl_accPH_rechercher_patient.setBackground(new java.awt.Color(204, 204, 204));
        lbl_accPH_rechercher_patient.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        lbl_accPH_rechercher_patient.setForeground(new java.awt.Color(204, 204, 204));
        lbl_accPH_rechercher_patient.setText("RECHERCHER UN PATIENT");
        lbl_accPH_rechercher_patient.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        lbl_accPH_nom.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        lbl_accPH_nom.setForeground(new java.awt.Color(255, 255, 255));
        lbl_accPH_nom.setText("Nom :");

        txt_accPH_nom.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_accPH_nom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_accPH_nomActionPerformed(evt);
            }
        });

        lbl_accPH_prenom.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        lbl_accPH_prenom.setForeground(new java.awt.Color(255, 255, 255));
        lbl_accPH_prenom.setText("Prénom :");

        txt_accPH_prenom.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_accPH_prenom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_accPH_prenomActionPerformed(evt);
            }
        });

        lbl_accPH_date_naissance.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        lbl_accPH_date_naissance.setForeground(new java.awt.Color(255, 255, 255));
        lbl_accPH_date_naissance.setText("Date de naissance :");

        txt_accPH_date_naissance.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_accPH_date_naissance.setText("yyyy-mm-dd");
        txt_accPH_date_naissance.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_accPH_date_naissanceFocusGained(evt);
            }
        });
        txt_accPH_date_naissance.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt_accPH_date_naissanceMouseClicked(evt);
            }
        });
        txt_accPH_date_naissance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_accPH_date_naissanceActionPerformed(evt);
            }
        });
        txt_accPH_date_naissance.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_accPH_date_naissanceKeyPressed(evt);
            }
        });

        but_accPH_rechercher.setBackground(new java.awt.Color(255, 255, 255));
        but_accPH_rechercher.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        but_accPH_rechercher.setText("Rechercher");
        but_accPH_rechercher.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        but_accPH_rechercher.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                but_accPH_rechercherMouseClicked(evt);
            }
        });
        but_accPH_rechercher.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                but_accPH_rechercherActionPerformed(evt);
            }
        });

        lbl_accPH_ajouter_patient.setBackground(new java.awt.Color(204, 204, 204));
        lbl_accPH_ajouter_patient.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        lbl_accPH_ajouter_patient.setForeground(new java.awt.Color(204, 204, 204));
        lbl_accPH_ajouter_patient.setText("AJOUTER UN PATIENT");
        lbl_accPH_ajouter_patient.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        but_accPH_ajouter.setBackground(new java.awt.Color(255, 255, 255));
        but_accPH_ajouter.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        but_accPH_ajouter.setText("Ajouter");
        but_accPH_ajouter.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        but_accPH_ajouter.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                but_accPH_ajouterMouseClicked(evt);
            }
        });

        but_accPH_deconnection.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imageProjet/Deconnection.png"))); // NOI18N
        but_accPH_deconnection.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                but_accPH_deconnectionMouseClicked(evt);
            }
        });
        but_accPH_deconnection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                but_accPH_deconnectionActionPerformed(evt);
            }
        });

        but_accPH_accueil.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imageProjet/logo.png"))); // NOI18N
        but_accPH_accueil.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(255, 255, 255), new java.awt.Color(255, 255, 255), new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0)));
        but_accPH_accueil.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                but_accPH_accueilMouseClicked(evt);
            }
        });
        but_accPH_accueil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                but_accPH_accueilActionPerformed(evt);
            }
        });

        lbl_accPH_examen.setBackground(new java.awt.Color(204, 204, 204));
        lbl_accPH_examen.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        lbl_accPH_examen.setForeground(new java.awt.Color(204, 204, 204));
        lbl_accPH_examen.setText("AJOUTER UN EXAMEN");
        lbl_accPH_examen.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        but_accPH_examen.setBackground(new java.awt.Color(255, 255, 255));
        but_accPH_examen.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        but_accPH_examen.setText("Ajouter");
        but_accPH_examen.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        but_accPH_examen.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                but_accPH_examenMouseClicked(evt);
            }
        });

        lbl_accPH_compte_rendu.setBackground(new java.awt.Color(204, 204, 204));
        lbl_accPH_compte_rendu.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        lbl_accPH_compte_rendu.setForeground(new java.awt.Color(204, 204, 204));
        lbl_accPH_compte_rendu.setText("ECRIRE UN COMPTE RENDU");
        lbl_accPH_compte_rendu.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        but_accPH_compte_rendu.setBackground(new java.awt.Color(255, 255, 255));
        but_accPH_compte_rendu.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        but_accPH_compte_rendu.setText("Ecrire");
        but_accPH_compte_rendu.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        but_accPH_compte_rendu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                but_accPH_compte_renduMouseClicked(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("retour à l'accueil");

        javax.swing.GroupLayout barrePHLayout = new javax.swing.GroupLayout(barrePH);
        barrePH.setLayout(barrePHLayout);
        barrePHLayout.setHorizontalGroup(
            barrePHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(barrePHLayout.createSequentialGroup()
                .addGroup(barrePHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(barrePHLayout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addComponent(lbl_accPH_question, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(barrePHLayout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(barrePHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(barrePHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(lbl_accPH_examen, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(barrePHLayout.createSequentialGroup()
                                    .addGroup(barrePHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(but_accPH_examen, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, barrePHLayout.createSequentialGroup()
                                            .addGap(91, 91, 91)
                                            .addComponent(but_accPH_compte_rendu, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGap(8, 8, 8)))
                            .addGroup(barrePHLayout.createSequentialGroup()
                                .addComponent(lbl_accPH_nom, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(30, 30, 30)
                                .addComponent(txt_accPH_nom, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(barrePHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(barrePHLayout.createSequentialGroup()
                                    .addComponent(lbl_accPH_date_naissance, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(txt_accPH_date_naissance))
                                .addGroup(barrePHLayout.createSequentialGroup()
                                    .addComponent(lbl_accPH_prenom, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(10, 10, 10)
                                    .addComponent(txt_accPH_prenom, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(barrePHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, barrePHLayout.createSequentialGroup()
                                    .addGap(90, 90, 90)
                                    .addComponent(but_accPH_rechercher, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(barrePHLayout.createSequentialGroup()
                                    .addComponent(but_accPH_ajouter, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(8, 8, 8))
                                .addComponent(lbl_accPH_ajouter_patient, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(barrePHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(lbl_accPH_compte_rendu, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(lbl_accPH_rechercher_patient, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(barrePHLayout.createSequentialGroup()
                        .addGap(87, 87, 87)
                        .addComponent(but_accPH_deconnection, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(barrePHLayout.createSequentialGroup()
                        .addGap(80, 80, 80)
                        .addGroup(barrePHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(but_accPH_accueil)
                            .addGroup(barrePHLayout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jLabel1)))))
                .addGap(76, 76, 76))
        );
        barrePHLayout.setVerticalGroup(
            barrePHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(barrePHLayout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(but_accPH_accueil)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addGap(30, 30, 30)
                .addComponent(lbl_accPH_question, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addComponent(lbl_accPH_compte_rendu)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(but_accPH_compte_rendu, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(lbl_accPH_examen)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(but_accPH_examen, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(lbl_accPH_rechercher_patient)
                .addGap(41, 41, 41)
                .addGroup(barrePHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_accPH_nom)
                    .addComponent(txt_accPH_nom, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(barrePHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(barrePHLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(lbl_accPH_prenom))
                    .addComponent(txt_accPH_prenom, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(barrePHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_accPH_date_naissance, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_accPH_date_naissance))
                .addGap(20, 20, 20)
                .addComponent(but_accPH_rechercher, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(lbl_accPH_ajouter_patient)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(but_accPH_ajouter, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 199, Short.MAX_VALUE)
                .addComponent(but_accPH_deconnection)
                .addGap(51, 51, 51))
        );

        getContentPane().add(barrePH, java.awt.BorderLayout.WEST);

        fonctionnalitePH.setBackground(new java.awt.Color(255, 255, 255));
        fonctionnalitePH.setBorder(new javax.swing.border.MatteBorder(null));
        fonctionnalitePH.setLayout(new java.awt.BorderLayout());
        getContentPane().add(fonctionnalitePH, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void txt_accPH_date_naissanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_accPH_date_naissanceActionPerformed
    }//GEN-LAST:event_txt_accPH_date_naissanceActionPerformed
    private void txt_accPH_nomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_accPH_nomActionPerformed
    }//GEN-LAST:event_txt_accPH_nomActionPerformed
    private void txt_accPH_prenomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_accPH_prenomActionPerformed
    }//GEN-LAST:event_txt_accPH_prenomActionPerformed
    private void but_accPH_deconnectionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_but_accPH_deconnectionMouseClicked
        //Fermeture Accueil à la deconnection
        this.dispose();
        //Ouverture de l'ecran de log
        new Root().setVisible(true);
    }//GEN-LAST:event_but_accPH_deconnectionMouseClicked
    private void but_accPH_rechercherMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_but_accPH_rechercherMouseClicked
        rechercherPatientPH(); 

    }//GEN-LAST:event_but_accPH_rechercherMouseClicked

    private void but_accPH_deconnectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_but_accPH_deconnectionActionPerformed
       
    }//GEN-LAST:event_but_accPH_deconnectionActionPerformed
    private void but_accPH_rechercherActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_but_accPH_rechercherActionPerformed

    }//GEN-LAST:event_but_accPH_rechercherActionPerformed
    private void but_accPH_ajouterMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_but_accPH_ajouterMouseClicked
        new AjouterPatient().setVisible(true);
    }//GEN-LAST:event_but_accPH_ajouterMouseClicked
    private void but_accPH_accueilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_but_accPH_accueilActionPerformed
    }//GEN-LAST:event_but_accPH_accueilActionPerformed
    private void but_accPH_accueilMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_but_accPH_accueilMouseClicked
        //Retour à l'acceuil
        fonctionnalitePH.removeAll();
        fonctionnalitePH.add(frontPageSE);
        validate();
        repaint();
        txt_accPH_date_naissance.setText("yyyy-mm-dd");
    }//GEN-LAST:event_but_accPH_accueilMouseClicked

    private void txt_accPH_date_naissanceMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt_accPH_date_naissanceMouseClicked
        if (txt_accPH_date_naissance.getText().equals("yyyy-mm-dd")){
            //Vidage du contenu du champs txt_AJ_date_naissance
            txt_accPH_date_naissance.setText(null);
        }
    }//GEN-LAST:event_txt_accPH_date_naissanceMouseClicked

    private void but_accPH_examenMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_but_accPH_examenMouseClicked
        new AjouterExamenPH().setVisible(true);
    }//GEN-LAST:event_but_accPH_examenMouseClicked

    private void but_accPH_compte_renduMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_but_accPH_compte_renduMouseClicked
        new AjouterCRPH().setVisible(true);
    }//GEN-LAST:event_but_accPH_compte_renduMouseClicked

    private void txt_accPH_date_naissanceFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_accPH_date_naissanceFocusGained
        if (txt_accPH_date_naissance.getText().equals("yyyy-mm-dd")){
            //Vidage du contenu du champs txt_AJ_date_naissance
            txt_accPH_date_naissance.setText(null);
        }
    }//GEN-LAST:event_txt_accPH_date_naissanceFocusGained

    private void txt_accPH_date_naissanceKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_accPH_date_naissanceKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER){
            rechercherPatientPH();    
        }
    }//GEN-LAST:event_txt_accPH_date_naissanceKeyPressed
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AccueilPH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AccueilPH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AccueilPH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AccueilPH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AccueilPH().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel barrePH;
    private javax.swing.JButton but_accPH_accueil;
    private javax.swing.JButton but_accPH_ajouter;
    private javax.swing.JButton but_accPH_compte_rendu;
    private javax.swing.JButton but_accPH_deconnection;
    private javax.swing.JButton but_accPH_examen;
    private javax.swing.JButton but_accPH_rechercher;
    private javax.swing.JPanel fonctionnalitePH;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel lbl_accPH_ajouter_patient;
    private javax.swing.JLabel lbl_accPH_compte_rendu;
    private javax.swing.JLabel lbl_accPH_date_naissance;
    private javax.swing.JLabel lbl_accPH_examen;
    private javax.swing.JLabel lbl_accPH_nom;
    private javax.swing.JLabel lbl_accPH_prenom;
    private javax.swing.JLabel lbl_accPH_question;
    private javax.swing.JLabel lbl_accPH_rechercher_patient;
    private javax.swing.JTextField txt_accPH_date_naissance;
    private javax.swing.JTextField txt_accPH_nom;
    private javax.swing.JTextField txt_accPH_prenom;
    // End of variables declaration//GEN-END:variables
}
