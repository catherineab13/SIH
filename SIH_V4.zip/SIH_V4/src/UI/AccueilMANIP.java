package UI;

import NF.FichePatient;
import static UI.FonctionsDonnees.pane_popup;
import static java.awt.Frame.MAXIMIZED_BOTH;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;

public class AccueilMANIP extends javax.swing.JFrame {
    AfficherPatientMA afficherPatientMA=new AfficherPatientMA();
    
    //Page d'accueil
    FrontPage frontPageSE=new FrontPage();
    
    public AccueilMANIP() {
        initComponents();
        this.setExtendedState(MAXIMIZED_BOTH);
        //init de l'accueil
        fonctionnaliteMA.removeAll();
        fonctionnaliteMA.add(frontPageSE);
        this.setVisible(true);
        
    }
      
    void rechercherPatientMA(String nom, String prenom, String date_naissance){
        //SI LES INFORMATIONS SONT AU BON FORMAT
        if (FonctionsDonnees.verifFormatDonnees(nom, prenom, date_naissance)){
            FichePatient pat_rech=FichePatient.rechercherPatient(nom, prenom, date_naissance);
            //SI LE PATIENT EXISTE
            if(pat_rech.getNom()!=null){
                //nettoyage des champs et de la fenetre
                fonctionnaliteMA.removeAll();
                txt_accMA_nom.setText("");
                txt_accMA_prenom.setText("");
                txt_accMA_date_naissance.setText("yyyy-mm-dd");
                //LOAD DE L'INTERFACE PH
                fonctionnaliteMA.add(this.afficherPatientMA);
                afficherPatientMA.loadPatMA(pat_rech);
                //ON REDESSINE L'INTERFACE
                validate();
                repaint();               
            }
            else{
                pane_popup.showMessageDialog(null, "Le patient n'existe pas", "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        }      
    }
    
     @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        barreMA = new javax.swing.JPanel();
        lbl_accMA_question = new javax.swing.JLabel();
        lbl_accMA_rechercher_patient = new javax.swing.JLabel();
        lbl_accMA_nom = new javax.swing.JLabel();
        txt_accMA_nom = new javax.swing.JTextField();
        lbl_accMA_prenom = new javax.swing.JLabel();
        txt_accMA_prenom = new javax.swing.JTextField();
        lbl_accMA_date_naissance = new javax.swing.JLabel();
        txt_accMA_date_naissance = new javax.swing.JTextField();
        but_accMA_rechercher = new javax.swing.JButton();
        lbl_accMA_ajouter_patient = new javax.swing.JLabel();
        but_accMA_ajouter = new javax.swing.JButton();
        but_accMA_deconnection = new javax.swing.JButton();
        but_accMA_accueil = new javax.swing.JButton();
        lbl_accMA_examen = new javax.swing.JLabel();
        but_accMA_examen = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        fonctionnaliteMA = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1920, 1080));

        barreMA.setBackground(new java.awt.Color(1, 95, 191));
        barreMA.setBorder(javax.swing.BorderFactory.createCompoundBorder());
        barreMA.setMaximumSize(new java.awt.Dimension(300, 1080));
        barreMA.setMinimumSize(new java.awt.Dimension(300, 1080));
        barreMA.setPreferredSize(new java.awt.Dimension(300, 1080));

        lbl_accMA_question.setBackground(new java.awt.Color(1, 95, 191));
        lbl_accMA_question.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        lbl_accMA_question.setForeground(new java.awt.Color(255, 255, 255));
        lbl_accMA_question.setText("Que souhaitez-vous faire ?");

        lbl_accMA_rechercher_patient.setBackground(new java.awt.Color(204, 204, 204));
        lbl_accMA_rechercher_patient.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        lbl_accMA_rechercher_patient.setForeground(new java.awt.Color(204, 204, 204));
        lbl_accMA_rechercher_patient.setText("RECHERCHER UN PATIENT");
        lbl_accMA_rechercher_patient.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        lbl_accMA_nom.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        lbl_accMA_nom.setForeground(new java.awt.Color(255, 255, 255));
        lbl_accMA_nom.setText("Nom :");

        txt_accMA_nom.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_accMA_nom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_accMA_nomActionPerformed(evt);
            }
        });

        lbl_accMA_prenom.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        lbl_accMA_prenom.setForeground(new java.awt.Color(255, 255, 255));
        lbl_accMA_prenom.setText("Prénom :");

        txt_accMA_prenom.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_accMA_prenom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_accMA_prenomActionPerformed(evt);
            }
        });

        lbl_accMA_date_naissance.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        lbl_accMA_date_naissance.setForeground(new java.awt.Color(255, 255, 255));
        lbl_accMA_date_naissance.setText("Date de naissance :");

        txt_accMA_date_naissance.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_accMA_date_naissance.setText("yyyy-mm-dd");
        txt_accMA_date_naissance.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_accMA_date_naissanceFocusGained(evt);
            }
        });
        txt_accMA_date_naissance.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt_accMA_date_naissanceMouseClicked(evt);
            }
        });
        txt_accMA_date_naissance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_accMA_date_naissanceActionPerformed(evt);
            }
        });
        txt_accMA_date_naissance.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_accMA_date_naissanceKeyPressed(evt);
            }
        });

        but_accMA_rechercher.setBackground(new java.awt.Color(255, 255, 255));
        but_accMA_rechercher.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        but_accMA_rechercher.setText("Rechercher");
        but_accMA_rechercher.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        but_accMA_rechercher.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                but_accMA_rechercherMouseClicked(evt);
            }
        });
        but_accMA_rechercher.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                but_accMA_rechercherActionPerformed(evt);
            }
        });

        lbl_accMA_ajouter_patient.setBackground(new java.awt.Color(204, 204, 204));
        lbl_accMA_ajouter_patient.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        lbl_accMA_ajouter_patient.setForeground(new java.awt.Color(204, 204, 204));
        lbl_accMA_ajouter_patient.setText("AJOUTER UN PATIENT");
        lbl_accMA_ajouter_patient.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        but_accMA_ajouter.setBackground(new java.awt.Color(255, 255, 255));
        but_accMA_ajouter.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        but_accMA_ajouter.setText("Ajouter");
        but_accMA_ajouter.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        but_accMA_ajouter.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                but_accMA_ajouterMouseClicked(evt);
            }
        });

        but_accMA_deconnection.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imageProjet/Deconnection.png"))); // NOI18N
        but_accMA_deconnection.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                but_accMA_deconnectionMouseClicked(evt);
            }
        });
        but_accMA_deconnection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                but_accMA_deconnectionActionPerformed(evt);
            }
        });

        but_accMA_accueil.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imageProjet/logo.png"))); // NOI18N
        but_accMA_accueil.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(255, 255, 255), new java.awt.Color(255, 255, 255), new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0)));
        but_accMA_accueil.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                but_accMA_accueilMouseClicked(evt);
            }
        });
        but_accMA_accueil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                but_accMA_accueilActionPerformed(evt);
            }
        });

        lbl_accMA_examen.setBackground(new java.awt.Color(204, 204, 204));
        lbl_accMA_examen.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        lbl_accMA_examen.setForeground(new java.awt.Color(204, 204, 204));
        lbl_accMA_examen.setText("AJOUTER UN EXAMEN");
        lbl_accMA_examen.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        but_accMA_examen.setBackground(new java.awt.Color(255, 255, 255));
        but_accMA_examen.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        but_accMA_examen.setText("Ajouter");
        but_accMA_examen.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        but_accMA_examen.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                but_accMA_examenMouseClicked(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("retour à l'accueil");

        javax.swing.GroupLayout barreMALayout = new javax.swing.GroupLayout(barreMA);
        barreMA.setLayout(barreMALayout);
        barreMALayout.setHorizontalGroup(
            barreMALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(barreMALayout.createSequentialGroup()
                .addGroup(barreMALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(barreMALayout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addComponent(lbl_accMA_question, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(barreMALayout.createSequentialGroup()
                        .addGap(87, 87, 87)
                        .addComponent(but_accMA_deconnection, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(barreMALayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(barreMALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(barreMALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(lbl_accMA_examen, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(barreMALayout.createSequentialGroup()
                                    .addComponent(but_accMA_examen, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(8, 8, 8)))
                            .addGroup(barreMALayout.createSequentialGroup()
                                .addComponent(lbl_accMA_nom, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(30, 30, 30)
                                .addComponent(txt_accMA_nom, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(barreMALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(barreMALayout.createSequentialGroup()
                                    .addComponent(lbl_accMA_date_naissance, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(txt_accMA_date_naissance))
                                .addGroup(barreMALayout.createSequentialGroup()
                                    .addComponent(lbl_accMA_prenom, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(10, 10, 10)
                                    .addComponent(txt_accMA_prenom, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(barreMALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, barreMALayout.createSequentialGroup()
                                    .addGap(90, 90, 90)
                                    .addComponent(but_accMA_rechercher, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(barreMALayout.createSequentialGroup()
                                    .addComponent(but_accMA_ajouter, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(8, 8, 8))
                                .addComponent(lbl_accMA_ajouter_patient, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(lbl_accMA_rechercher_patient, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(barreMALayout.createSequentialGroup()
                        .addGap(80, 80, 80)
                        .addGroup(barreMALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(barreMALayout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jLabel1))
                            .addComponent(but_accMA_accueil))))
                .addGap(20, 20, 20))
        );
        barreMALayout.setVerticalGroup(
            barreMALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(barreMALayout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(but_accMA_accueil)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addGap(30, 30, 30)
                .addComponent(lbl_accMA_question, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(lbl_accMA_examen)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(but_accMA_examen, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(lbl_accMA_rechercher_patient)
                .addGap(41, 41, 41)
                .addGroup(barreMALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_accMA_nom)
                    .addComponent(txt_accMA_nom, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(barreMALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(barreMALayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(lbl_accMA_prenom))
                    .addComponent(txt_accMA_prenom, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(barreMALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_accMA_date_naissance, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_accMA_date_naissance))
                .addGap(20, 20, 20)
                .addComponent(but_accMA_rechercher, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(lbl_accMA_ajouter_patient)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(but_accMA_ajouter, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 302, Short.MAX_VALUE)
                .addComponent(but_accMA_deconnection)
                .addGap(51, 51, 51))
        );

        getContentPane().add(barreMA, java.awt.BorderLayout.WEST);

        fonctionnaliteMA.setBackground(new java.awt.Color(255, 255, 255));
        fonctionnaliteMA.setBorder(new javax.swing.border.MatteBorder(null));
        fonctionnaliteMA.setMaximumSize(new java.awt.Dimension(1620, 1080));
        fonctionnaliteMA.setMinimumSize(new java.awt.Dimension(1620, 1080));
        fonctionnaliteMA.setPreferredSize(new java.awt.Dimension(1620, 1080));
        fonctionnaliteMA.setLayout(new java.awt.BorderLayout());
        getContentPane().add(fonctionnaliteMA, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void txt_accMA_date_naissanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_accMA_date_naissanceActionPerformed
    }//GEN-LAST:event_txt_accMA_date_naissanceActionPerformed
    private void txt_accMA_nomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_accMA_nomActionPerformed
    }//GEN-LAST:event_txt_accMA_nomActionPerformed
    private void txt_accMA_prenomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_accMA_prenomActionPerformed
    }//GEN-LAST:event_txt_accMA_prenomActionPerformed
    private void but_accMA_deconnectionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_but_accMA_deconnectionMouseClicked
        //Fermeture Accueil à la deconnection
        this.dispose();
        //Ouverture de l'ecran de log
        new Root().setVisible(true);
    }//GEN-LAST:event_but_accMA_deconnectionMouseClicked
    private void but_accMA_rechercherMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_but_accMA_rechercherMouseClicked
        //recuperation des informations pour la recherche
        String nom_a_rech = txt_accMA_nom.getText();
        String prenom_a_rech = txt_accMA_prenom.getText();
        String date_naissance_a_rech = txt_accMA_date_naissance.getText();
        
        //FORMATAGE DES INFORMATIONS RENSEIGNEES
        nom_a_rech = nom_a_rech.toUpperCase();
        prenom_a_rech = prenom_a_rech.toUpperCase();
        
        rechercherPatientMA(nom_a_rech,prenom_a_rech,date_naissance_a_rech); 
    }//GEN-LAST:event_but_accMA_rechercherMouseClicked

    private void but_accMA_deconnectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_but_accMA_deconnectionActionPerformed
       
    }//GEN-LAST:event_but_accMA_deconnectionActionPerformed
    private void but_accMA_rechercherActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_but_accMA_rechercherActionPerformed

    }//GEN-LAST:event_but_accMA_rechercherActionPerformed
    private void but_accMA_ajouterMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_but_accMA_ajouterMouseClicked
        new AjouterPatient().setVisible(true);        
    }//GEN-LAST:event_but_accMA_ajouterMouseClicked
    private void but_accMA_accueilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_but_accMA_accueilActionPerformed
    }//GEN-LAST:event_but_accMA_accueilActionPerformed
    private void but_accMA_accueilMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_but_accMA_accueilMouseClicked
        //Retour à l'acceuil
        fonctionnaliteMA.removeAll();
        fonctionnaliteMA.add(frontPageSE);
        validate();
        repaint();
        txt_accMA_nom.setText("");
        txt_accMA_prenom.setText("");
        txt_accMA_date_naissance.setText("yyyy-mm-dd");
    }//GEN-LAST:event_but_accMA_accueilMouseClicked

    private void txt_accMA_date_naissanceMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt_accMA_date_naissanceMouseClicked
        if (txt_accMA_date_naissance.getText().equals("yyyy-mm-dd")){
            //Vidage du contenu du champs txt_AJ_date_naissance
            txt_accMA_date_naissance.setText(null);
        }
    }//GEN-LAST:event_txt_accMA_date_naissanceMouseClicked

    private void but_accMA_examenMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_but_accMA_examenMouseClicked
        new AjouterExamenMA().setVisible(true);
    }//GEN-LAST:event_but_accMA_examenMouseClicked

    private void txt_accMA_date_naissanceFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_accMA_date_naissanceFocusGained
        if (txt_accMA_date_naissance.getText().equals("yyyy-mm-dd")){
            //Vidage du contenu du champs txt_AJ_date_naissance
            txt_accMA_date_naissance.setText(null);
        }
    }//GEN-LAST:event_txt_accMA_date_naissanceFocusGained

    private void txt_accMA_date_naissanceKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_accMA_date_naissanceKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER){
            //recuperation des informations pour la recherche
            String nom_a_rech = txt_accMA_nom.getText();
            String prenom_a_rech = txt_accMA_prenom.getText();
            String date_naissance_a_rech = txt_accMA_date_naissance.getText();
        
            //FORMATAGE DES INFORMATIONS RENSEIGNEES
            nom_a_rech = nom_a_rech.toUpperCase();
            prenom_a_rech = prenom_a_rech.toUpperCase();
        
            rechercherPatientMA(nom_a_rech,prenom_a_rech,date_naissance_a_rech); 
        }
    }//GEN-LAST:event_txt_accMA_date_naissanceKeyPressed
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AccueilMANIP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AccueilMANIP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AccueilMANIP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AccueilMANIP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AccueilMANIP().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel barreMA;
    private javax.swing.JButton but_accMA_accueil;
    private javax.swing.JButton but_accMA_ajouter;
    private javax.swing.JButton but_accMA_deconnection;
    private javax.swing.JButton but_accMA_examen;
    private javax.swing.JButton but_accMA_rechercher;
    private javax.swing.JPanel fonctionnaliteMA;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel lbl_accMA_ajouter_patient;
    private javax.swing.JLabel lbl_accMA_date_naissance;
    private javax.swing.JLabel lbl_accMA_examen;
    private javax.swing.JLabel lbl_accMA_nom;
    private javax.swing.JLabel lbl_accMA_prenom;
    private javax.swing.JLabel lbl_accMA_question;
    private javax.swing.JLabel lbl_accMA_rechercher_patient;
    private javax.swing.JTextField txt_accMA_date_naissance;
    private javax.swing.JTextField txt_accMA_nom;
    private javax.swing.JTextField txt_accMA_prenom;
    // End of variables declaration//GEN-END:variables
}
