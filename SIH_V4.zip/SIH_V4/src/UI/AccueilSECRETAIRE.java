package UI;

import NF.FichePatient;
import static UI.FonctionsDonnees.pane_popup;
import static java.awt.Frame.MAXIMIZED_BOTH;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;

public class AccueilSECRETAIRE extends javax.swing.JFrame {
    AfficherPatientSE afficherPatientSE=new AfficherPatientSE();
    
    //Page d'accueil
    FrontPage frontPageSE=new FrontPage();
    
    public AccueilSECRETAIRE() {
        initComponents();
        this.setExtendedState(MAXIMIZED_BOTH);
        //init de l'accueil
        fonctionnaliteSE.removeAll();
        fonctionnaliteSE.add(frontPageSE);
        this.setVisible(true);
        
    }
      
    void rechercherPatientSE(){
        //recuperation des informations pour la recherche
        String nom_a_rech = txt_accSE_nom.getText();
        String prenom_a_rech = txt_accSE_prenom.getText();
        String date_naissance_a_rech = txt_accSE_date_naissance.getText();
        //FORMATAGE DES INFORMATIONS RENSEIGNEES
        nom_a_rech = nom_a_rech.toUpperCase();
        prenom_a_rech = prenom_a_rech.toUpperCase();
        //SI LES INFORMATIONS SONT AU BON FORMAT
        if (FonctionsDonnees.verifFormatDonnees(nom_a_rech, prenom_a_rech, date_naissance_a_rech)){
            FichePatient pat_rech=FichePatient.rechercherPatient(nom_a_rech, prenom_a_rech, date_naissance_a_rech);
            //SI LE PATIENT EXISTE
            if(pat_rech.getNom()!=null){
                //nettoyage des champs et de la fenetre
                fonctionnaliteSE.removeAll();
                txt_accSE_nom.setText("");
                txt_accSE_prenom.setText("");
                txt_accSE_date_naissance.setText("yyyy-mm-dd");
                //LOAD DE L'INTERFACE PH
                fonctionnaliteSE.add(this.afficherPatientSE);
                afficherPatientSE.loadPatSE(pat_rech);
                //ON REDESSINE L'INTERFACE
                validate();
                repaint();               
            }
            else{
                pane_popup.showMessageDialog(null, "Le patient n'existe pas", "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        }      
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        barreSE = new javax.swing.JPanel();
        lbl_accSE_question = new javax.swing.JLabel();
        lbl_accSE_rechercher_patient = new javax.swing.JLabel();
        lbl_accSE_nom = new javax.swing.JLabel();
        txt_accSE_nom = new javax.swing.JTextField();
        lbl_accSE_prenom = new javax.swing.JLabel();
        txt_accSE_prenom = new javax.swing.JTextField();
        lbl_accSE_date_naissance = new javax.swing.JLabel();
        txt_accSE_date_naissance = new javax.swing.JTextField();
        but_accSE_rechercher = new javax.swing.JButton();
        lbl_accSE_ajouter_patient = new javax.swing.JLabel();
        but_accSE_ajouter = new javax.swing.JButton();
        but_accSE_deconnection = new javax.swing.JButton();
        but_accSE_accueil = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        fonctionnaliteSE = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1920, 1080));

        barreSE.setBackground(new java.awt.Color(1, 95, 191));
        barreSE.setBorder(javax.swing.BorderFactory.createCompoundBorder());
        barreSE.setMaximumSize(new java.awt.Dimension(300, 1080));
        barreSE.setMinimumSize(new java.awt.Dimension(300, 1080));
        barreSE.setPreferredSize(new java.awt.Dimension(300, 1080));

        lbl_accSE_question.setBackground(new java.awt.Color(1, 95, 191));
        lbl_accSE_question.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        lbl_accSE_question.setForeground(new java.awt.Color(255, 255, 255));
        lbl_accSE_question.setText("Que souhaitez-vous faire ?");

        lbl_accSE_rechercher_patient.setBackground(new java.awt.Color(204, 204, 204));
        lbl_accSE_rechercher_patient.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        lbl_accSE_rechercher_patient.setForeground(new java.awt.Color(204, 204, 204));
        lbl_accSE_rechercher_patient.setText("RECHERCHER UN PATIENT");
        lbl_accSE_rechercher_patient.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        lbl_accSE_nom.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        lbl_accSE_nom.setForeground(new java.awt.Color(255, 255, 255));
        lbl_accSE_nom.setText("Nom :");

        txt_accSE_nom.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_accSE_nom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_accSE_nomActionPerformed(evt);
            }
        });

        lbl_accSE_prenom.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        lbl_accSE_prenom.setForeground(new java.awt.Color(255, 255, 255));
        lbl_accSE_prenom.setText("Prénom :");

        txt_accSE_prenom.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_accSE_prenom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_accSE_prenomActionPerformed(evt);
            }
        });

        lbl_accSE_date_naissance.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        lbl_accSE_date_naissance.setForeground(new java.awt.Color(255, 255, 255));
        lbl_accSE_date_naissance.setText("Date de naissance :");

        txt_accSE_date_naissance.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_accSE_date_naissance.setText("yyyy-mm-dd");
        txt_accSE_date_naissance.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_accSE_date_naissanceFocusGained(evt);
            }
        });
        txt_accSE_date_naissance.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt_accSE_date_naissanceMouseClicked(evt);
            }
        });
        txt_accSE_date_naissance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_accSE_date_naissanceActionPerformed(evt);
            }
        });
        txt_accSE_date_naissance.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_accSE_date_naissanceKeyPressed(evt);
            }
        });

        but_accSE_rechercher.setBackground(new java.awt.Color(255, 255, 255));
        but_accSE_rechercher.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        but_accSE_rechercher.setText("Rechercher");
        but_accSE_rechercher.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        but_accSE_rechercher.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                but_accSE_rechercherMouseClicked(evt);
            }
        });
        but_accSE_rechercher.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                but_accSE_rechercherActionPerformed(evt);
            }
        });

        lbl_accSE_ajouter_patient.setBackground(new java.awt.Color(204, 204, 204));
        lbl_accSE_ajouter_patient.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        lbl_accSE_ajouter_patient.setForeground(new java.awt.Color(204, 204, 204));
        lbl_accSE_ajouter_patient.setText("AJOUTER UN PATIENT");
        lbl_accSE_ajouter_patient.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        but_accSE_ajouter.setBackground(new java.awt.Color(255, 255, 255));
        but_accSE_ajouter.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        but_accSE_ajouter.setText("Ajouter");
        but_accSE_ajouter.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        but_accSE_ajouter.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                but_accSE_ajouterMouseClicked(evt);
            }
        });
        but_accSE_ajouter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                but_accSE_ajouterActionPerformed(evt);
            }
        });

        but_accSE_deconnection.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imageProjet/Deconnection.png"))); // NOI18N
        but_accSE_deconnection.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                but_accSE_deconnectionMouseClicked(evt);
            }
        });
        but_accSE_deconnection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                but_accSE_deconnectionActionPerformed(evt);
            }
        });

        but_accSE_accueil.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imageProjet/logo.png"))); // NOI18N
        but_accSE_accueil.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(255, 255, 255), new java.awt.Color(255, 255, 255), new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0)));
        but_accSE_accueil.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                but_accSE_accueilMouseClicked(evt);
            }
        });
        but_accSE_accueil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                but_accSE_accueilActionPerformed(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("retour à l'accueil");

        javax.swing.GroupLayout barreSELayout = new javax.swing.GroupLayout(barreSE);
        barreSE.setLayout(barreSELayout);
        barreSELayout.setHorizontalGroup(
            barreSELayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(barreSELayout.createSequentialGroup()
                .addGroup(barreSELayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(barreSELayout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addComponent(lbl_accSE_question, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(barreSELayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(lbl_accSE_rechercher_patient, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(barreSELayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(lbl_accSE_nom, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addComponent(txt_accSE_nom, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(barreSELayout.createSequentialGroup()
                        .addGap(74, 74, 74)
                        .addComponent(but_accSE_deconnection, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(barreSELayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(barreSELayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(barreSELayout.createSequentialGroup()
                                .addComponent(lbl_accSE_date_naissance, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txt_accSE_date_naissance))
                            .addGroup(barreSELayout.createSequentialGroup()
                                .addComponent(lbl_accSE_prenom, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(txt_accSE_prenom, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(barreSELayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, barreSELayout.createSequentialGroup()
                            .addGap(20, 20, 20)
                            .addComponent(lbl_accSE_ajouter_patient, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, barreSELayout.createSequentialGroup()
                            .addGap(110, 110, 110)
                            .addComponent(but_accSE_rechercher, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(barreSELayout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(but_accSE_ajouter, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(8, 8, 8)))
                    .addGroup(barreSELayout.createSequentialGroup()
                        .addGap(80, 80, 80)
                        .addGroup(barreSELayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(barreSELayout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jLabel1))
                            .addComponent(but_accSE_accueil))))
                .addGap(20, 20, 20))
        );
        barreSELayout.setVerticalGroup(
            barreSELayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(barreSELayout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(but_accSE_accueil)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addGap(30, 30, 30)
                .addComponent(lbl_accSE_question, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addComponent(lbl_accSE_rechercher_patient)
                .addGap(41, 41, 41)
                .addGroup(barreSELayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_accSE_nom)
                    .addComponent(txt_accSE_nom, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(barreSELayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(barreSELayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(lbl_accSE_prenom))
                    .addComponent(txt_accSE_prenom, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(barreSELayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_accSE_date_naissance, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_accSE_date_naissance))
                .addGap(20, 20, 20)
                .addComponent(but_accSE_rechercher, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(lbl_accSE_ajouter_patient)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(but_accSE_ajouter, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 318, Short.MAX_VALUE)
                .addComponent(but_accSE_deconnection)
                .addGap(100, 100, 100))
        );

        getContentPane().add(barreSE, java.awt.BorderLayout.WEST);

        fonctionnaliteSE.setBackground(new java.awt.Color(255, 255, 255));
        fonctionnaliteSE.setBorder(new javax.swing.border.MatteBorder(null));
        fonctionnaliteSE.setMaximumSize(new java.awt.Dimension(1620, 1080));
        fonctionnaliteSE.setMinimumSize(new java.awt.Dimension(1620, 1080));
        fonctionnaliteSE.setPreferredSize(new java.awt.Dimension(1620, 1080));
        fonctionnaliteSE.setLayout(new java.awt.BorderLayout());
        getContentPane().add(fonctionnaliteSE, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void txt_accSE_date_naissanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_accSE_date_naissanceActionPerformed
    }//GEN-LAST:event_txt_accSE_date_naissanceActionPerformed
    private void txt_accSE_nomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_accSE_nomActionPerformed
    }//GEN-LAST:event_txt_accSE_nomActionPerformed
    private void txt_accSE_prenomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_accSE_prenomActionPerformed
    }//GEN-LAST:event_txt_accSE_prenomActionPerformed
    private void but_accSE_deconnectionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_but_accSE_deconnectionMouseClicked
        //Fermeture Accueil à la deconnection
        this.dispose();
        //Ouverture de l'ecran de log
        new Root().setVisible(true);
    }//GEN-LAST:event_but_accSE_deconnectionMouseClicked
    private void but_accSE_rechercherMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_but_accSE_rechercherMouseClicked
        rechercherPatientSE();        
    }//GEN-LAST:event_but_accSE_rechercherMouseClicked

    private void but_accSE_deconnectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_but_accSE_deconnectionActionPerformed
       
    }//GEN-LAST:event_but_accSE_deconnectionActionPerformed
    private void but_accSE_rechercherActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_but_accSE_rechercherActionPerformed

    }//GEN-LAST:event_but_accSE_rechercherActionPerformed
    private void but_accSE_ajouterMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_but_accSE_ajouterMouseClicked
        new AjouterPatient().setVisible(true);
    }//GEN-LAST:event_but_accSE_ajouterMouseClicked
    private void but_accSE_accueilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_but_accSE_accueilActionPerformed
    }//GEN-LAST:event_but_accSE_accueilActionPerformed
    private void but_accSE_accueilMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_but_accSE_accueilMouseClicked
        //Retour à l'acceuil
        fonctionnaliteSE.removeAll();
        fonctionnaliteSE.add(frontPageSE);
        validate();
        repaint();
        txt_accSE_date_naissance.setText("yyyy-mm-dd");
    }//GEN-LAST:event_but_accSE_accueilMouseClicked

    private void txt_accSE_date_naissanceMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt_accSE_date_naissanceMouseClicked
    }//GEN-LAST:event_txt_accSE_date_naissanceMouseClicked

    private void but_accSE_ajouterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_but_accSE_ajouterActionPerformed

    }//GEN-LAST:event_but_accSE_ajouterActionPerformed

    private void txt_accSE_date_naissanceFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_accSE_date_naissanceFocusGained
  if (txt_accSE_date_naissance.getText().equals("yyyy-mm-dd")){
            //Vidage du contenu du champs txt_AJ_date_naissance
            txt_accSE_date_naissance.setText(null);
        }
    }//GEN-LAST:event_txt_accSE_date_naissanceFocusGained

    private void txt_accSE_date_naissanceKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_accSE_date_naissanceKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER){
            rechercherPatientSE();    
        }
    }//GEN-LAST:event_txt_accSE_date_naissanceKeyPressed
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AccueilSECRETAIRE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AccueilSECRETAIRE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AccueilSECRETAIRE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AccueilSECRETAIRE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AccueilSECRETAIRE().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel barreSE;
    private javax.swing.JButton but_accSE_accueil;
    private javax.swing.JButton but_accSE_ajouter;
    private javax.swing.JButton but_accSE_deconnection;
    private javax.swing.JButton but_accSE_rechercher;
    private javax.swing.JPanel fonctionnaliteSE;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel lbl_accSE_ajouter_patient;
    private javax.swing.JLabel lbl_accSE_date_naissance;
    private javax.swing.JLabel lbl_accSE_nom;
    private javax.swing.JLabel lbl_accSE_prenom;
    private javax.swing.JLabel lbl_accSE_question;
    private javax.swing.JLabel lbl_accSE_rechercher_patient;
    private javax.swing.JTextField txt_accSE_date_naissance;
    private javax.swing.JTextField txt_accSE_nom;
    private javax.swing.JTextField txt_accSE_prenom;
    // End of variables declaration//GEN-END:variables
}
