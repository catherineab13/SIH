package UI;

import NF.FicheExamen;
import NF.FichePatient;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

public class AfficherPatientMA extends javax.swing.JPanel {

    public AfficherPatientMA() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbl_reMA_titre = new javax.swing.JLabel();
        lbl_reMA_nom = new javax.swing.JLabel();
        txt_reMA_nom = new javax.swing.JTextField();
        lbl_reMA_prenom = new javax.swing.JLabel();
        txt_reMA_prenom = new javax.swing.JTextField();
        txt_reMA_date_naissance = new javax.swing.JTextField();
        lbl_reMA_date_naissance = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tab_reMA_exam = new javax.swing.JTable();

        setBackground(new java.awt.Color(255, 255, 255));
        setMaximumSize(new java.awt.Dimension(1620, 1080));
        setMinimumSize(new java.awt.Dimension(1620, 1080));

        lbl_reMA_titre.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lbl_reMA_titre.setText("Résultat de la recherche");

        lbl_reMA_nom.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_reMA_nom.setText("Nom :");

        txt_reMA_nom.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        lbl_reMA_prenom.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_reMA_prenom.setText("Prénom :");

        txt_reMA_prenom.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_reMA_prenom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_reMA_prenomActionPerformed(evt);
            }
        });

        txt_reMA_date_naissance.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_reMA_date_naissance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_reMA_date_naissanceActionPerformed(evt);
            }
        });

        lbl_reMA_date_naissance.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_reMA_date_naissance.setText("Date de naissance :");

        tab_reMA_exam.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Date de l'Examen", "Type d'Examen", "Nom du PH responsable", "Prénom du PH responsable"
            }
        ));
        jScrollPane1.setViewportView(tab_reMA_exam);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(636, 636, 636)
                        .addComponent(lbl_reMA_titre, javax.swing.GroupLayout.PREFERRED_SIZE, 276, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(469, 469, 469)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbl_reMA_prenom)
                            .addComponent(lbl_reMA_nom)
                            .addComponent(lbl_reMA_date_naissance))
                        .addGap(172, 172, 172)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_reMA_date_naissance, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_reMA_prenom, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_reMA_nom, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(394, 394, 394)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 789, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(437, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(80, 80, 80)
                .addComponent(lbl_reMA_titre, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_reMA_nom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_reMA_nom))
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_reMA_prenom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_reMA_prenom))
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_reMA_date_naissance, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_reMA_date_naissance))
                .addGap(76, 76, 76)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(271, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents
    private void txt_reMA_date_naissanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_reMA_date_naissanceActionPerformed

    }//GEN-LAST:event_txt_reMA_date_naissanceActionPerformed
    private void txt_reMA_prenomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_reMA_prenomActionPerformed

    }//GEN-LAST:event_txt_reMA_prenomActionPerformed

    public void addRowToExamens() {
        DefaultTableModel model = (DefaultTableModel) tab_reMA_exam.getModel();
        Object rowData[] = new Object[4];
        ArrayList<FicheExamen> fichesExamPat = new ArrayList<FicheExamen>();
        fichesExamPat = FicheExamen.trouverInfosExamensPatient(new FichePatient(txt_reMA_nom.getText(), txt_reMA_prenom.getText(), txt_reMA_date_naissance.getText()));
        for (int i = 0; i < fichesExamPat.size(); i++) {
            rowData[0] = fichesExamPat.get(i).getDateExamen();
            rowData[1] = fichesExamPat.get(i).getTypeImage();
            rowData[2] = fichesExamPat.get(i).getPHRespo().getNomPHRespo();
            rowData[3] = fichesExamPat.get(i).getPHRespo().getPrenomPHRespo();
            model.addRow(rowData);
        }
    }

    public void emptyRowToExamens() {
        DefaultTableModel model = (DefaultTableModel) tab_reMA_exam.getModel();
        model.setRowCount(0);
    }

    public void loadPatMA(FichePatient pat) {
        this.emptyRowToExamens();
        txt_reMA_nom.setText(pat.getNom());
        txt_reMA_prenom.setText(pat.getPrenom());
        txt_reMA_date_naissance.setText(pat.getDateDeNaissance());
        this.addRowToExamens();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbl_reMA_date_naissance;
    private javax.swing.JLabel lbl_reMA_nom;
    private javax.swing.JLabel lbl_reMA_prenom;
    private javax.swing.JLabel lbl_reMA_titre;
    private javax.swing.JTable tab_reMA_exam;
    private javax.swing.JTextField txt_reMA_date_naissance;
    private javax.swing.JTextField txt_reMA_nom;
    private javax.swing.JTextField txt_reMA_prenom;
    // End of variables declaration//GEN-END:variables
}
