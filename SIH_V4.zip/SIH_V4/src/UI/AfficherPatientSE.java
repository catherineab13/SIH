package UI;

import NF.FichePatient;

public class AfficherPatientSE extends javax.swing.JPanel {
    public AfficherPatientSE() {initComponents();}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg_reSE_genre = new javax.swing.ButtonGroup();
        lbl_reSE_titre = new javax.swing.JLabel();
        lbl_reSE_nom = new javax.swing.JLabel();
        txt_reSE_nom = new javax.swing.JTextField();
        lbl_reSE_prenom = new javax.swing.JLabel();
        txt_reSE_prenom = new javax.swing.JTextField();
        lbl_reSE_date_naissance = new javax.swing.JLabel();
        txt_reSE_date_naissance = new javax.swing.JTextField();
        lbl_reSE_adresse = new javax.swing.JLabel();
        txt_reSE_adresse = new javax.swing.JTextField();
        lbl_reSE_ville = new javax.swing.JLabel();
        txt_reSE_ville = new javax.swing.JTextField();
        lbl_reSE_code_postal = new javax.swing.JLabel();
        txt_reSE_code_postal = new javax.swing.JTextField();
        lbl_reSE_pays = new javax.swing.JLabel();
        txt_reSE_pays = new javax.swing.JTextField();
        but_reSE_ok = new javax.swing.JButton();
        lbl_reSE_genre = new javax.swing.JLabel();
        rb_reSE_H = new javax.swing.JRadioButton();
        rb_reSE_F = new javax.swing.JRadioButton();

        setBackground(new java.awt.Color(255, 255, 255));
        setMaximumSize(new java.awt.Dimension(1620, 1080));
        setMinimumSize(new java.awt.Dimension(1620, 1080));

        lbl_reSE_titre.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lbl_reSE_titre.setText("Résultat de la recherche");

        lbl_reSE_nom.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_reSE_nom.setText("Nom :");

        txt_reSE_nom.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        lbl_reSE_prenom.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_reSE_prenom.setText("Prénom :");

        txt_reSE_prenom.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_reSE_prenom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_reSE_prenomActionPerformed(evt);
            }
        });

        lbl_reSE_date_naissance.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_reSE_date_naissance.setText("Date de naissance :");

        txt_reSE_date_naissance.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_reSE_date_naissance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_reSE_date_naissanceActionPerformed(evt);
            }
        });

        lbl_reSE_adresse.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_reSE_adresse.setText("Adresse :");

        txt_reSE_adresse.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_reSE_adresse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_reSE_adresseActionPerformed(evt);
            }
        });

        lbl_reSE_ville.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_reSE_ville.setText("Ville :");

        txt_reSE_ville.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        lbl_reSE_code_postal.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_reSE_code_postal.setText("Code postal :");

        txt_reSE_code_postal.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_reSE_code_postal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_reSE_code_postalActionPerformed(evt);
            }
        });

        lbl_reSE_pays.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_reSE_pays.setText("Pays :");

        txt_reSE_pays.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_reSE_pays.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_reSE_paysActionPerformed(evt);
            }
        });

        but_reSE_ok.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        but_reSE_ok.setText("OK");
        but_reSE_ok.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        lbl_reSE_genre.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_reSE_genre.setText("Sexe :");

        rb_reSE_H.setText("H");
        rb_reSE_H.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rb_reSE_HActionPerformed(evt);
            }
        });

        rb_reSE_F.setText("F");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(636, 636, 636)
                        .addComponent(lbl_reSE_titre, javax.swing.GroupLayout.PREFERRED_SIZE, 276, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(469, 469, 469)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lbl_reSE_prenom)
                                    .addComponent(lbl_reSE_nom))
                                .addGap(234, 234, 234)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txt_reSE_nom, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_reSE_prenom, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lbl_reSE_date_naissance)
                                    .addComponent(lbl_reSE_adresse)
                                    .addComponent(lbl_reSE_code_postal)
                                    .addComponent(lbl_reSE_ville)
                                    .addComponent(lbl_reSE_pays)
                                    .addComponent(lbl_reSE_genre))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(172, 172, 172)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txt_reSE_date_naissance, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txt_reSE_adresse, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txt_reSE_ville, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txt_reSE_code_postal, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txt_reSE_pays, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(267, 267, 267)
                                        .addComponent(rb_reSE_H)
                                        .addGap(47, 47, 47)
                                        .addComponent(rb_reSE_F))))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(749, 749, 749)
                        .addComponent(but_reSE_ok, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(556, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(80, 80, 80)
                .addComponent(lbl_reSE_titre, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_reSE_nom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_reSE_nom))
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_reSE_prenom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_reSE_prenom))
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_reSE_genre)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(rb_reSE_F)
                        .addComponent(rb_reSE_H)))
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_reSE_date_naissance, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_reSE_date_naissance))
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_reSE_adresse, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_reSE_adresse))
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_reSE_ville, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_reSE_ville))
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_reSE_code_postal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_reSE_code_postal))
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_reSE_pays, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_reSE_pays))
                .addGap(73, 73, 73)
                .addComponent(but_reSE_ok)
                .addContainerGap(399, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents
    private void txt_reSE_date_naissanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_reSE_date_naissanceActionPerformed

    }//GEN-LAST:event_txt_reSE_date_naissanceActionPerformed
    private void txt_reSE_prenomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_reSE_prenomActionPerformed

    }//GEN-LAST:event_txt_reSE_prenomActionPerformed
    private void txt_reSE_adresseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_reSE_adresseActionPerformed

    }//GEN-LAST:event_txt_reSE_adresseActionPerformed
    private void txt_reSE_code_postalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_reSE_code_postalActionPerformed
        
    }//GEN-LAST:event_txt_reSE_code_postalActionPerformed
    private void txt_reSE_paysActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_reSE_paysActionPerformed
       
    }//GEN-LAST:event_txt_reSE_paysActionPerformed

    private void rb_reSE_HActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rb_reSE_HActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rb_reSE_HActionPerformed
    
   public void loadPatSE(FichePatient pat) {
        txt_reSE_nom.setText(pat.getNom());
        txt_reSE_prenom.setText(pat.getPrenom());
        txt_reSE_date_naissance.setText(pat.getDateDeNaissance());
        txt_reSE_adresse.setText(pat.getAdresse());
        txt_reSE_ville.setText(pat.getVille());
        txt_reSE_code_postal.setText(Integer.toString(pat.getCodePostal()));
        txt_reSE_pays.setText(pat.getPays());
        rb_reSE_H.setSelected(pat.getGenre().equals("H"));
        rb_reSE_F.setSelected(pat.getGenre().equals("F"));
} 

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup bg_reSE_genre;
    private javax.swing.JButton but_reSE_ok;
    private javax.swing.JLabel lbl_reSE_adresse;
    private javax.swing.JLabel lbl_reSE_code_postal;
    private javax.swing.JLabel lbl_reSE_date_naissance;
    private javax.swing.JLabel lbl_reSE_genre;
    private javax.swing.JLabel lbl_reSE_nom;
    private javax.swing.JLabel lbl_reSE_pays;
    private javax.swing.JLabel lbl_reSE_prenom;
    private javax.swing.JLabel lbl_reSE_titre;
    private javax.swing.JLabel lbl_reSE_ville;
    private javax.swing.JRadioButton rb_reSE_F;
    private javax.swing.JRadioButton rb_reSE_H;
    private javax.swing.JTextField txt_reSE_adresse;
    private javax.swing.JTextField txt_reSE_code_postal;
    private javax.swing.JTextField txt_reSE_date_naissance;
    private javax.swing.JTextField txt_reSE_nom;
    private javax.swing.JTextField txt_reSE_pays;
    private javax.swing.JTextField txt_reSE_prenom;
    private javax.swing.JTextField txt_reSE_ville;
    // End of variables declaration//GEN-END:variables
}
