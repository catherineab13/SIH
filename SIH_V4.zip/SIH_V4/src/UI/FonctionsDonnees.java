package UI;

import NF.FichePatient;
import NF.FichePatient;
import NF.FichePatient;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.swing.JOptionPane;

public class FonctionsDonnees {

//VARIABLES STATIC DEBUT
    //Format date static
    static public SimpleDateFormat patternDateDeNaissance = new SimpleDateFormat("yyyy-MM-dd");
    static public SimpleDateFormat patternDateExamen = new SimpleDateFormat("yyyy-MM-dd-HH-mm");
    //Panel ERROR static
    static public JOptionPane pane_popup = new JOptionPane();
    //Nom utilisateur
    static public String nom_user = "";
//VARIABLES STATIC FIN

//FONCTIONS STATIC DEBUT
    //Fonction verification de l'existence d'une date
    static public boolean verifExistenceDate(String str_date) {
        try {
            int annee = Integer.parseInt(str_date.substring(0, 4));
            int mois = Integer.parseInt(str_date.substring(5, 7)) - 1;
            int jour = Integer.parseInt(str_date.substring(8, 10));
            GregorianCalendar GC = new GregorianCalendar(annee, mois, jour);
            // controle de la validite de la date.
            GC.setLenient(false);
            // c'est a la lecture qu'il y a l'eventuelle exception
            annee = GC.get(GregorianCalendar.YEAR);
            mois = GC.get(GregorianCalendar.MONTH);
            jour = GC.get(GregorianCalendar.DAY_OF_MONTH);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    //Fonction Verification du format de la date de naissance
    static public boolean verifFormatDateNaissance(String str_date) {
        Calendar cal_date = Calendar.getInstance();
        try {
            Date date_naissance = patternDateDeNaissance.parse(str_date);
            cal_date.setTime(date_naissance);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    //Fonction Verification du format de la date d'examen
    static public boolean verifFormatDateExamen(String str_date) {
        Calendar cal_date = Calendar.getInstance();
        try {
            Date date_exam = patternDateExamen.parse(str_date);
            cal_date.setTime(date_exam);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    //Convertir une date en string
    static public String dateToString(Date date) {
        String String_date = null;
        try {
            String_date = patternDateDeNaissance.format(date);
        } catch (Exception ex) {
        }
        return String_date;
    }

    static public Date stringToDate(String str_date) {
        Date date = new Date();
        try {
            date = patternDateDeNaissance.parse(str_date);
        } catch (Exception ex) {
        }
        return date;
    }

    //VERIFICATION DES DONNEES SAISIES
    //Format Patient réduit
    static public Boolean verifFormatDonnees(String nom_verif, String prenom_verif, String date_naissance_verif) {
        //flag verif format donnees accueil
        int flag_verif = 1;
        //NOM non renseigne
        if (nom_verif.equals("")) {
            flag_verif = 0;
            FonctionsDonnees.pane_popup.showMessageDialog(null, "Le nom n'a pas été renseigné", "Erreur", JOptionPane.ERROR_MESSAGE);
        } //PRENOM non renseigne
        else if (prenom_verif.equals("")) {
            flag_verif = 0;
            FonctionsDonnees.pane_popup.showMessageDialog(null, "Le prénom n'a pas été renseigné", "Erreur", JOptionPane.ERROR_MESSAGE);
        } //DATE non renseignee
        else if (date_naissance_verif.equals("")) {
            flag_verif = 0;
            FonctionsDonnees.pane_popup.showMessageDialog(null, "La date n'a pas été renseignée", "Erreur", JOptionPane.ERROR_MESSAGE);
        } //DATE au mauvais format
        else if (!FonctionsDonnees.verifFormatDateNaissance(date_naissance_verif)) {
            flag_verif = 0;
            FonctionsDonnees.pane_popup.showMessageDialog(null, "La date n'a pas le bon format", "Erreur", JOptionPane.ERROR_MESSAGE);
        } //DATE n'existe pas
        else if (!FonctionsDonnees.verifExistenceDate(date_naissance_verif)) {
            flag_verif = 0;
            FonctionsDonnees.pane_popup.showMessageDialog(null, "La date n'existe pas", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
        if (flag_verif == 1) {
            return true;
        } else {
            return false;
        }
    }

    //Format Patient full
    static public Boolean verifFormatDonnees(String nom_verif, String genre_verif, String prenom_verif, String date_naissance_verif, String adresse_verif, String ville_verif, String code_postal_verif, String pays_verif) {
        //flag verif format donnees accueil
        int flag_verif = 1;
        //NOM non renseigne
        if (nom_verif.equals("")) {
            flag_verif = 0;
            pane_popup.showMessageDialog(null, "Le nom n'a pas été renseigné", "Erreur", JOptionPane.ERROR_MESSAGE);
        } 
        //Genre non renseigne
        else if (genre_verif.equals("")) {
            flag_verif = 0;
            pane_popup.showMessageDialog(null, "Le sexe n'a pas été renseigné", "Erreur", JOptionPane.ERROR_MESSAGE);
        } 
        //PRENOM non renseigne
        else if (prenom_verif.equals("")) {
            flag_verif = 0;
            pane_popup.showMessageDialog(null, "Le prénom n'a pas été renseigné", "Erreur", JOptionPane.ERROR_MESSAGE);
        } 
        //DATE non renseignee
        else if (date_naissance_verif.equals("")) {
            flag_verif = 0;
            pane_popup.showMessageDialog(null, "La date n'a pas été renseignée", "Erreur", JOptionPane.ERROR_MESSAGE);
        } 
        //DATE au mauvais format
        else if (!FonctionsDonnees.verifFormatDateNaissance(date_naissance_verif)) {
            flag_verif = 0;
            pane_popup.showMessageDialog(null, "La date n'a pas le bon format", "Erreur", JOptionPane.ERROR_MESSAGE);
        } 
        //DATE n'existe pas
        else if (!FonctionsDonnees.verifExistenceDate(date_naissance_verif)) {
            flag_verif = 0;
            pane_popup.showMessageDialog(null, "La date n'existe pas", "Erreur", JOptionPane.ERROR_MESSAGE);
        } 
        //ADRESSE non renseignee
        else if (adresse_verif.equals("")) {
            flag_verif = 0;
            pane_popup.showMessageDialog(null, "L'adresse n'a pas été renseignée", "Erreur", JOptionPane.ERROR_MESSAGE);
        } 
        //VILLE non renseignee
        else if (ville_verif.equals("")) {
            flag_verif = 0;
            pane_popup.showMessageDialog(null, "La ville n'a pas été renseignée", "Erreur", JOptionPane.ERROR_MESSAGE);
        } 
        //CP non renseigne
        else if (code_postal_verif.equals("")) {
            flag_verif = 0;
            pane_popup.showMessageDialog(null, "Le code postal n'a pas été renseigné", "Erreur", JOptionPane.ERROR_MESSAGE);
        } 
        //CP pas au bon format
        else if (!code_postal_verif.matches("\\d{5}")) {
            flag_verif = 0;
            pane_popup.showMessageDialog(null, "Le code postal n'a pas le bon format", "Erreur", JOptionPane.ERROR_MESSAGE);
        } 
        //PAYS non renseigne
        else if (pays_verif.equals("")) {
            flag_verif = 0;
            pane_popup.showMessageDialog(null, "Le pays n'a pas été renseigné", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
        
        if (flag_verif == 1) {
            return true;
        } else {
            return false;
        }
    }

    //Format Examen
    static public Boolean verifFormatDonnees(String date_exam_verif, String type_add_verif, String nom_pat_verif, String prenom_pat_verif, String date_naissance_pat_verif, String nom_ph_verif, String prenom_ph_verif) {
        //flag verif format donnees accueil
        int flag_verif = 1;

        //TYPE D'EXAMEN non renseigne
        if (type_add_verif.equals("")) {
            flag_verif = 0;
            pane_popup.showMessageDialog(null, "Le type d'examen n'a pas été renseigné", "Erreur", JOptionPane.ERROR_MESSAGE);
        } 
        //DATE D'EXAMEN non renseignee
        else if (date_exam_verif.equals("")) {
            flag_verif = 0;
            pane_popup.showMessageDialog(null, "La date n'a pas été renseignée", "Erreur", JOptionPane.ERROR_MESSAGE);
        } 
        //DATE D'EXAMEN au mauvais format
        else if (!FonctionsDonnees.verifFormatDateExamen(date_exam_verif)) {
            flag_verif = 0;
            pane_popup.showMessageDialog(null, "La date n'a pas le bon format", "Erreur", JOptionPane.ERROR_MESSAGE);
        } 
        //DATE D'EXAMEN n'existe pas
        else if (!FonctionsDonnees.verifExistenceDate(date_exam_verif)) {
            flag_verif = 0;
            pane_popup.showMessageDialog(null, "La date n'existe pas", "Erreur", JOptionPane.ERROR_MESSAGE);
        } 
        //NOM non renseigne
        else if (nom_pat_verif.equals("")) {
            flag_verif = 0;
            pane_popup.showMessageDialog(null, "Le nom du patient n'a pas été renseigné", "Erreur", JOptionPane.ERROR_MESSAGE);
        } 
        //PRENOM non renseigne
        else if (prenom_pat_verif.equals("")) {
            flag_verif = 0;
            pane_popup.showMessageDialog(null, "Le prénom n'a pas été renseigné", "Erreur", JOptionPane.ERROR_MESSAGE);
        } 
        //DATE NAISSANCE non renseignee
        else if (date_naissance_pat_verif.equals("")) {
            flag_verif = 0;
            pane_popup.showMessageDialog(null, "La date de naissance du patient n'a pas été renseignée", "Erreur", JOptionPane.ERROR_MESSAGE);
        } 
        //DATE NAISSANCE au mauvais format
        else if (!FonctionsDonnees.verifFormatDateNaissance(date_naissance_pat_verif)) {
            flag_verif = 0;
            pane_popup.showMessageDialog(null, "La date n'a pas le bon format", "Erreur", JOptionPane.ERROR_MESSAGE);
        } 
        //DATE n'existe pas
        else if (!FonctionsDonnees.verifExistenceDate(date_naissance_pat_verif)) {
            flag_verif = 0;
            pane_popup.showMessageDialog(null, "La date n'existe pas", "Erreur", JOptionPane.ERROR_MESSAGE);
        } 
        //NOM PH non renseigne
        else if (nom_pat_verif.equals("")) {
            flag_verif = 0;
            pane_popup.showMessageDialog(null, "Le nom du PH n'a pas été renseigné", "Erreur", JOptionPane.ERROR_MESSAGE);
        } 
        //PRENOM PH non renseigne
        else if (prenom_pat_verif.equals("")) {
            flag_verif = 0;
            pane_popup.showMessageDialog(null, "Le prénom du PH n'a pas été renseigné", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
        
        if (flag_verif == 1) {
            return true;
        } else {
            return false;
        }
//FONCTIONS STATIC FIN
    }

}
