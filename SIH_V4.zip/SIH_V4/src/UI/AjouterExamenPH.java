package UI;

import NF.FicheExamen;
import NF.FichePatient;
import static UI.FonctionsDonnees.pane_popup;
import javax.swing.JOptionPane;

public class AjouterExamenPH extends javax.swing.JFrame {
    public AjouterExamenPH() {
        initComponents();
    }

    void addExamPH(){
        //recuperation des informations pour la recherche
        String date_exam=txt_AEPH_date_exam.getText();
        String nom_a_rech_pat = txt_AEPH_nom_pat.getText();
        String prenom_a_rech_pat = txt_AEPH_prenom_pat.getText();
        String date_naissance_a_rech_pat = txt_AEPH_date_naissance_pat.getText();
        String nom_a_rech_ph = txt_AEPH_nom_ph.getText();
        String prenom_a_rech_ph = txt_AEPH_prenom_ph.getText();
        String remarque_add = txt_AEPH_remarque.getText();
        String type_add="";
        if (rb_AEPH_irm.isSelected()){type_add="IRM";}
        else if(rb_AEPH_scanner.isSelected()){type_add="SCANNER";}
        else if(rb_AEPH_radio.isSelected()){type_add="RADIO";}
        
        //FORMATAGE DES INFORMATIONS RENSEIGNEES
        nom_a_rech_pat = nom_a_rech_pat.toUpperCase();
        prenom_a_rech_pat = prenom_a_rech_pat.toUpperCase();
        nom_a_rech_ph = nom_a_rech_ph.toUpperCase();
        prenom_a_rech_ph = prenom_a_rech_ph.toUpperCase();
        type_add = type_add.toUpperCase();
        
        //SI LES INFORMATIONS SONT AU BON FORMAT
        if(FonctionsDonnees.verifFormatDonnees(date_exam,type_add,nom_a_rech_pat,prenom_a_rech_pat,date_naissance_a_rech_pat,nom_a_rech_ph,prenom_a_rech_ph)){
            //SI LE PATIENT EXISTE ET QUE LE MEDECIN PH REF EXISTE !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            FichePatient pat_a_rech=FichePatient.rechercherPatient(nom_a_rech_pat, prenom_a_rech_pat, date_naissance_a_rech_pat);
            if (pat_a_rech.getNom()!=null){
                //Creation nouvel exam
//                FicheExamen exam_add = new FicheExamen (type_add, date_exam, nom_a_rech_ph, prenom_a_rech_ph, pat_a_rech, remarque_add);
                //AJOUTER EXAM A BDD
//                exam_add.addExamen();
                pane_popup.showMessageDialog(null, "L'examen a bien été ajouté", "Erreur", JOptionPane.INFORMATION_MESSAGE);
                //Fermeture du popup
                this.dispose();
            }
            else {
                pane_popup.showMessageDialog(null, "Le patient n'existe pas", "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        }
        
        
            
    }
        
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jFrame1 = new javax.swing.JFrame();
        bg_AEPH_type_image = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        lbl_AEPH_titre = new javax.swing.JLabel();
        lbl_AEPH_date_exam = new javax.swing.JLabel();
        lbl_AEPH_type_image = new javax.swing.JLabel();
        rb_AEPH_scanner = new javax.swing.JRadioButton();
        rb_AEPH_irm = new javax.swing.JRadioButton();
        rb_AEPH_radio = new javax.swing.JRadioButton();
        lbl_AEPH_nom_pat = new javax.swing.JLabel();
        lbl_AEPH_prenom_pat = new javax.swing.JLabel();
        lbl_AEPH_nom_ph = new javax.swing.JLabel();
        lbl_AEPH_prenom_ph = new javax.swing.JLabel();
        but_AEPH_ok = new javax.swing.JButton();
        lbl_AEPH_date_naissance_pat = new javax.swing.JLabel();
        txt_AEPH_date_exam = new javax.swing.JTextField();
        txt_AEPH_nom_pat = new javax.swing.JTextField();
        txt_AEPH_prenom_pat = new javax.swing.JTextField();
        txt_AEPH_date_naissance_pat = new javax.swing.JTextField();
        txt_AEPH_nom_ph = new javax.swing.JTextField();
        txt_AEPH_prenom_ph = new javax.swing.JTextField();
        lbl_AEPH_format_date_exam = new javax.swing.JLabel();
        lbl_AEPH_format_date_naissance = new javax.swing.JLabel();
        lbl_AEPH_remarque = new javax.swing.JLabel();
        txt_AEPH_remarque = new java.awt.TextArea();
        lbl_AEPH_nom_ph1 = new javax.swing.JLabel();

        javax.swing.GroupLayout jFrame1Layout = new javax.swing.GroupLayout(jFrame1.getContentPane());
        jFrame1.getContentPane().setLayout(jFrame1Layout);
        jFrame1Layout.setHorizontalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame1Layout.setVerticalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(900, 800));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setMaximumSize(new java.awt.Dimension(900, 900));
        jPanel1.setMinimumSize(new java.awt.Dimension(900, 900));
        jPanel1.setPreferredSize(new java.awt.Dimension(900, 1000));

        lbl_AEPH_titre.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lbl_AEPH_titre.setText("Ajouter un examen (PH)");

        lbl_AEPH_date_exam.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_AEPH_date_exam.setText("Date : ");

        lbl_AEPH_type_image.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_AEPH_type_image.setText("Type d'examen :");

        bg_AEPH_type_image.add(rb_AEPH_scanner);
        rb_AEPH_scanner.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rb_AEPH_scanner.setText("Radiographie");
        rb_AEPH_scanner.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rb_AEPH_scannerActionPerformed(evt);
            }
        });

        bg_AEPH_type_image.add(rb_AEPH_irm);
        rb_AEPH_irm.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rb_AEPH_irm.setText("Scanner");
        rb_AEPH_irm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rb_AEPH_irmActionPerformed(evt);
            }
        });

        bg_AEPH_type_image.add(rb_AEPH_radio);
        rb_AEPH_radio.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rb_AEPH_radio.setText("IRM");

        lbl_AEPH_nom_pat.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_AEPH_nom_pat.setText("Nom du Patient :");

        lbl_AEPH_prenom_pat.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_AEPH_prenom_pat.setText("Prénom du Patient :");

        lbl_AEPH_nom_ph.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_AEPH_nom_ph.setText("Nom du PH responsable :");

        lbl_AEPH_prenom_ph.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_AEPH_prenom_ph.setText("Prénom du PH responsable :");

        but_AEPH_ok.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        but_AEPH_ok.setText("OK");
        but_AEPH_ok.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        but_AEPH_ok.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                but_AEPH_okMouseClicked(evt);
            }
        });

        lbl_AEPH_date_naissance_pat.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_AEPH_date_naissance_pat.setText("Date de naissance :");

        txt_AEPH_date_exam.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_AEPH_date_exam.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_AEPH_date_examFocusGained(evt);
            }
        });
        txt_AEPH_date_exam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_AEPH_date_examActionPerformed(evt);
            }
        });

        txt_AEPH_nom_pat.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        txt_AEPH_prenom_pat.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        txt_AEPH_date_naissance_pat.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_AEPH_date_naissance_pat.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_AEPH_date_naissance_patFocusGained(evt);
            }
        });

        txt_AEPH_nom_ph.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        txt_AEPH_prenom_ph.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        lbl_AEPH_format_date_exam.setFont(new java.awt.Font("Segoe UI", 2, 11)); // NOI18N
        lbl_AEPH_format_date_exam.setText("(yyyy-MM-dd-HH-mm)");

        lbl_AEPH_format_date_naissance.setFont(new java.awt.Font("Segoe UI", 2, 11)); // NOI18N
        lbl_AEPH_format_date_naissance.setText("(yyyy-MM-dd)");

        lbl_AEPH_remarque.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_AEPH_remarque.setText("Remarques sur l' examen :");

        lbl_AEPH_nom_ph1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_AEPH_nom_ph1.setText("Ajouter condition \"Si le PH REF existe\"");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(160, 160, 160)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(lbl_AEPH_type_image)
                                .addGap(63, 63, 63)
                                .addComponent(lbl_AEPH_titre))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lbl_AEPH_prenom_pat)
                                    .addComponent(lbl_AEPH_nom_pat)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(lbl_AEPH_date_exam)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lbl_AEPH_format_date_exam))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(lbl_AEPH_date_naissance_pat)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(lbl_AEPH_format_date_naissance)))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(15, 15, 15)
                                        .addComponent(txt_AEPH_date_naissance_pat, javax.swing.GroupLayout.PREFERRED_SIZE, 339, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txt_AEPH_date_exam, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(txt_AEPH_prenom_pat, javax.swing.GroupLayout.PREFERRED_SIZE, 339, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addComponent(rb_AEPH_scanner)
                                                        .addGap(52, 52, 52)
                                                        .addComponent(rb_AEPH_irm)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(rb_AEPH_radio))
                                                    .addComponent(txt_AEPH_nom_pat, javax.swing.GroupLayout.PREFERRED_SIZE, 339, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lbl_AEPH_nom_ph)
                                    .addComponent(lbl_AEPH_prenom_ph)
                                    .addComponent(lbl_AEPH_remarque))
                                .addGap(32, 32, 32)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txt_AEPH_prenom_ph, javax.swing.GroupLayout.DEFAULT_SIZE, 339, Short.MAX_VALUE)
                                    .addComponent(txt_AEPH_nom_ph, javax.swing.GroupLayout.DEFAULT_SIZE, 339, Short.MAX_VALUE)
                                    .addComponent(txt_AEPH_remarque, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(421, 421, 421)
                        .addComponent(but_AEPH_ok, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addComponent(lbl_AEPH_nom_ph1)))
                .addContainerGap(195, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(117, 117, 117)
                .addComponent(lbl_AEPH_titre)
                .addGap(81, 81, 81)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_AEPH_type_image)
                    .addComponent(rb_AEPH_irm)
                    .addComponent(rb_AEPH_scanner)
                    .addComponent(rb_AEPH_radio))
                .addGap(34, 34, 34)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_AEPH_date_exam)
                    .addComponent(txt_AEPH_date_exam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_AEPH_format_date_exam))
                .addGap(64, 64, 64)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_AEPH_nom_pat)
                    .addComponent(txt_AEPH_nom_pat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_AEPH_prenom_pat)
                    .addComponent(txt_AEPH_prenom_pat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_AEPH_date_naissance_pat)
                    .addComponent(txt_AEPH_date_naissance_pat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_AEPH_format_date_naissance))
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_AEPH_nom_ph)
                    .addComponent(txt_AEPH_nom_ph, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_AEPH_prenom_ph, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_AEPH_prenom_ph))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_AEPH_remarque)
                    .addComponent(txt_AEPH_remarque, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                .addComponent(but_AEPH_ok)
                .addGap(54, 54, 54)
                .addComponent(lbl_AEPH_nom_ph1)
                .addGap(23, 23, 23))
        );

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void but_AEPH_okMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_but_AEPH_okMouseClicked
        addExamPH();
    }//GEN-LAST:event_but_AEPH_okMouseClicked

    private void rb_AEPH_scannerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rb_AEPH_scannerActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rb_AEPH_scannerActionPerformed

    private void rb_AEPH_irmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rb_AEPH_irmActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rb_AEPH_irmActionPerformed

    private void txt_AEPH_date_examActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_AEPH_date_examActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_AEPH_date_examActionPerformed

    private void txt_AEPH_date_examFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_AEPH_date_examFocusGained

    }//GEN-LAST:event_txt_AEPH_date_examFocusGained

    private void txt_AEPH_date_naissance_patFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_AEPH_date_naissance_patFocusGained
   
    }//GEN-LAST:event_txt_AEPH_date_naissance_patFocusGained

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AjouterExamenPH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AjouterExamenPH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AjouterExamenPH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AjouterExamenPH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AjouterExamenPH().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup bg_AEPH_type_image;
    private javax.swing.JButton but_AEPH_ok;
    private javax.swing.JFrame jFrame1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lbl_AEPH_date_exam;
    private javax.swing.JLabel lbl_AEPH_date_naissance_pat;
    private javax.swing.JLabel lbl_AEPH_format_date_exam;
    private javax.swing.JLabel lbl_AEPH_format_date_naissance;
    private javax.swing.JLabel lbl_AEPH_nom_pat;
    private javax.swing.JLabel lbl_AEPH_nom_ph;
    private javax.swing.JLabel lbl_AEPH_nom_ph1;
    private javax.swing.JLabel lbl_AEPH_prenom_pat;
    private javax.swing.JLabel lbl_AEPH_prenom_ph;
    private javax.swing.JLabel lbl_AEPH_remarque;
    private javax.swing.JLabel lbl_AEPH_titre;
    private javax.swing.JLabel lbl_AEPH_type_image;
    private javax.swing.JRadioButton rb_AEPH_irm;
    private javax.swing.JRadioButton rb_AEPH_radio;
    private javax.swing.JRadioButton rb_AEPH_scanner;
    private javax.swing.JTextField txt_AEPH_date_exam;
    private javax.swing.JTextField txt_AEPH_date_naissance_pat;
    private javax.swing.JTextField txt_AEPH_nom_pat;
    private javax.swing.JTextField txt_AEPH_nom_ph;
    private javax.swing.JTextField txt_AEPH_prenom_pat;
    private javax.swing.JTextField txt_AEPH_prenom_ph;
    private java.awt.TextArea txt_AEPH_remarque;
    // End of variables declaration//GEN-END:variables
}
