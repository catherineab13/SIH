package UI;

import NF.FichePatient;
import javax.swing.JOptionPane;

public class AjouterPatient extends javax.swing.JFrame {
    public AjouterPatient() {
        initComponents();
    }

//Ajout du nouveau patient
    void ajoutPatient(){
        //On recupere les données des champs
        String nom_add = txt_AJ_nom.getText();
        String prenom_add = txt_AJ_prenom.getText();
        String date_naissance_add_string = txt_AJ_date_naissance.getText(); 
        String adresse_add = txt_AJ_adresse.getText();
        String ville_add = txt_AJ_ville.getText();
        String code_postal_add_string = txt_AJ_code_postal.getText();
        String pays_add = txt_AJ_pays.getText();
        String genre_add;
        if (rb_AJ_H.isSelected())
                {genre_add="H";}
            else {genre_add="F";}
        
        //FORMATAGE DES INFORMATIONS RENSEIGNEES
            nom_add = nom_add.toUpperCase();
            prenom_add = prenom_add.toUpperCase();
            adresse_add = adresse_add.toUpperCase();
            ville_add = ville_add.toUpperCase();
            pays_add = pays_add.toUpperCase();
            int code_postal_add = Integer.parseInt(code_postal_add_string);
            
        //VERIFICATION DES DONNEES SAISIES             
        //SI LES INFORMATIONS SONT AU BON FORMAT
        if(FonctionsDonnees.verifFormatDonnees(nom_add,prenom_add,genre_add,date_naissance_add_string,adresse_add,ville_add,code_postal_add_string,pays_add)){           
            //On verifie que le patient n'existe pas dans la BDD
                //Si le patient existe
                FichePatient pat_rech=new FichePatient();
                pat_rech.rechercherPatient(nom_add,prenom_add,date_naissance_add_string);
            if (pat_rech.getNom()!=null) { 
                FonctionsDonnees.pane_popup.showMessageDialog(null, "Le Patient existe déjà dans la base de données", "Ajout Patient", JOptionPane.INFORMATION_MESSAGE);
            } 
            //Le patient n'existe pas dans la base de données
            else { 
                //On cree le nouveau patient
                //On ajout le nouveau patient à la BDD
                pat_rech.ajouterPatientaBDD();
                FonctionsDonnees.pane_popup.showMessageDialog(null, "Le Patient a bien été ajouté à la base de donnée", "Ajout Patient", JOptionPane.INFORMATION_MESSAGE);
                //Fermeture du popup
                this.dispose();      
            } 
        }     
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jFrame1 = new javax.swing.JFrame();
        bg_AJ_genre = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        lbl_AJ_titre = new javax.swing.JLabel();
        lbl_AJ_nom = new javax.swing.JLabel();
        txt_AJ_nom = new javax.swing.JTextField();
        lbl_AJ_prenom = new javax.swing.JLabel();
        txt_AJ_prenom = new javax.swing.JTextField();
        lbl_AJ_date_naissance = new javax.swing.JLabel();
        txt_AJ_date_naissance = new javax.swing.JTextField();
        lbl_AJ_adresse = new javax.swing.JLabel();
        txt_AJ_adresse = new javax.swing.JTextField();
        lbl_AJ_ville = new javax.swing.JLabel();
        txt_AJ_ville = new javax.swing.JTextField();
        lbl_AJ_code_postal = new javax.swing.JLabel();
        txt_AJ_code_postal = new javax.swing.JTextField();
        lbl_AJ_pays = new javax.swing.JLabel();
        txt_AJ_pays = new javax.swing.JTextField();
        but_AJ_ok = new javax.swing.JButton();
        rb_AJ_F = new javax.swing.JRadioButton();
        rb_AJ_H = new javax.swing.JRadioButton();
        lbl_AJ_genre = new javax.swing.JLabel();

        javax.swing.GroupLayout jFrame1Layout = new javax.swing.GroupLayout(jFrame1.getContentPane());
        jFrame1.getContentPane().setLayout(jFrame1Layout);
        jFrame1Layout.setHorizontalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame1Layout.setVerticalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(900, 800));
        setMinimumSize(new java.awt.Dimension(900, 800));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setMaximumSize(new java.awt.Dimension(900, 800));
        jPanel1.setMinimumSize(new java.awt.Dimension(900, 800));
        jPanel1.setPreferredSize(new java.awt.Dimension(900, 800));

        lbl_AJ_titre.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lbl_AJ_titre.setText("Ajouter un patient");

        lbl_AJ_nom.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_AJ_nom.setText("Nom :");

        txt_AJ_nom.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_AJ_nom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_AJ_nomActionPerformed(evt);
            }
        });

        lbl_AJ_prenom.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_AJ_prenom.setText("Prénom :");

        txt_AJ_prenom.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_AJ_prenom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_AJ_prenomActionPerformed(evt);
            }
        });

        lbl_AJ_date_naissance.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_AJ_date_naissance.setText("Date de naissance :");

        txt_AJ_date_naissance.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_AJ_date_naissance.setText("yyyy-mm-dd");
        txt_AJ_date_naissance.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt_AJ_date_naissanceMouseClicked(evt);
            }
        });
        txt_AJ_date_naissance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_AJ_date_naissanceActionPerformed(evt);
            }
        });

        lbl_AJ_adresse.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_AJ_adresse.setText("Adresse :");

        txt_AJ_adresse.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_AJ_adresse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_AJ_adresseActionPerformed(evt);
            }
        });

        lbl_AJ_ville.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_AJ_ville.setText("Ville :");

        txt_AJ_ville.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_AJ_ville.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_AJ_villeActionPerformed(evt);
            }
        });

        lbl_AJ_code_postal.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_AJ_code_postal.setText("Code postal :");

        txt_AJ_code_postal.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_AJ_code_postal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_AJ_code_postalActionPerformed(evt);
            }
        });

        lbl_AJ_pays.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_AJ_pays.setText("Pays :");

        txt_AJ_pays.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txt_AJ_pays.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_AJ_paysActionPerformed(evt);
            }
        });

        but_AJ_ok.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        but_AJ_ok.setText("OK");
        but_AJ_ok.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        but_AJ_ok.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                but_AJ_okMouseClicked(evt);
            }
        });

        bg_AJ_genre.add(rb_AJ_F);
        rb_AJ_F.setText("F");

        bg_AJ_genre.add(rb_AJ_H);
        rb_AJ_H.setText("H");
        rb_AJ_H.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rb_AJ_HActionPerformed(evt);
            }
        });

        lbl_AJ_genre.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbl_AJ_genre.setText("Sexe :");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(188, 188, 188)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lbl_AJ_ville)
                                    .addComponent(lbl_AJ_code_postal)
                                    .addComponent(lbl_AJ_pays))
                                .addGap(129, 129, 129)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(txt_AJ_code_postal, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 285, Short.MAX_VALUE)
                                    .addComponent(txt_AJ_ville)
                                    .addComponent(txt_AJ_pays)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(lbl_AJ_prenom)
                                                .addComponent(lbl_AJ_nom))
                                            .addGap(62, 62, 62))
                                        .addComponent(lbl_AJ_date_naissance, javax.swing.GroupLayout.Alignment.TRAILING))
                                    .addComponent(lbl_AJ_adresse))
                                .addGap(92, 92, 92)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txt_AJ_adresse, javax.swing.GroupLayout.DEFAULT_SIZE, 285, Short.MAX_VALUE)
                                    .addComponent(txt_AJ_date_naissance)
                                    .addComponent(txt_AJ_prenom)
                                    .addComponent(txt_AJ_nom)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(lbl_AJ_genre)
                                .addGap(262, 262, 262)
                                .addComponent(rb_AJ_H)
                                .addGap(47, 47, 47)
                                .addComponent(rb_AJ_F))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(336, 336, 336)
                        .addComponent(lbl_AJ_titre)))
                .addContainerGap(218, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(but_AJ_ok, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(414, 414, 414))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(124, 124, 124)
                .addComponent(lbl_AJ_titre)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(157, 157, 157)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbl_AJ_prenom)
                            .addComponent(txt_AJ_prenom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(104, 104, 104)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_AJ_nom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbl_AJ_nom))))
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rb_AJ_F)
                    .addComponent(rb_AJ_H)
                    .addComponent(lbl_AJ_genre))
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_AJ_date_naissance)
                    .addComponent(txt_AJ_date_naissance, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_AJ_adresse)
                    .addComponent(txt_AJ_adresse, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_AJ_ville)
                    .addComponent(txt_AJ_ville, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_AJ_code_postal)
                    .addComponent(txt_AJ_code_postal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_AJ_pays)
                    .addComponent(txt_AJ_pays, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(67, 67, 67)
                .addComponent(but_AJ_ok)
                .addContainerGap())
        );

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    private void txt_AJ_nomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_AJ_nomActionPerformed
    }//GEN-LAST:event_txt_AJ_nomActionPerformed
    private void txt_AJ_date_naissanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_AJ_date_naissanceActionPerformed
    
    }//GEN-LAST:event_txt_AJ_date_naissanceActionPerformed
    private void txt_AJ_prenomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_AJ_prenomActionPerformed
      
    }//GEN-LAST:event_txt_AJ_prenomActionPerformed
    private void txt_AJ_adresseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_AJ_adresseActionPerformed
    
    }//GEN-LAST:event_txt_AJ_adresseActionPerformed
    private void txt_AJ_villeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_AJ_villeActionPerformed
    
    }//GEN-LAST:event_txt_AJ_villeActionPerformed
    private void txt_AJ_paysActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_AJ_paysActionPerformed
       
    }//GEN-LAST:event_txt_AJ_paysActionPerformed
    private void txt_AJ_code_postalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_AJ_code_postalActionPerformed
      
    }//GEN-LAST:event_txt_AJ_code_postalActionPerformed
    private void but_AJ_okMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_but_AJ_okMouseClicked
        ajoutPatient();
    }//GEN-LAST:event_but_AJ_okMouseClicked

    private void txt_AJ_date_naissanceMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt_AJ_date_naissanceMouseClicked
        if (txt_AJ_date_naissance.getText().equals("yyyy-mm-dd")){
            //Vidage du contenu du champs txt_AJ_date_naissance
            txt_AJ_date_naissance.setText(null);
        }
    }//GEN-LAST:event_txt_AJ_date_naissanceMouseClicked

    private void rb_AJ_HActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rb_AJ_HActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rb_AJ_HActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AjouterPatient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AjouterPatient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AjouterPatient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AjouterPatient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AjouterPatient().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup bg_AJ_genre;
    private javax.swing.JButton but_AJ_ok;
    private javax.swing.JFrame jFrame1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lbl_AJ_adresse;
    private javax.swing.JLabel lbl_AJ_code_postal;
    private javax.swing.JLabel lbl_AJ_date_naissance;
    private javax.swing.JLabel lbl_AJ_genre;
    private javax.swing.JLabel lbl_AJ_nom;
    private javax.swing.JLabel lbl_AJ_pays;
    private javax.swing.JLabel lbl_AJ_prenom;
    private javax.swing.JLabel lbl_AJ_titre;
    private javax.swing.JLabel lbl_AJ_ville;
    private javax.swing.JRadioButton rb_AJ_F;
    private javax.swing.JRadioButton rb_AJ_H;
    private javax.swing.JTextField txt_AJ_adresse;
    private javax.swing.JTextField txt_AJ_code_postal;
    private javax.swing.JTextField txt_AJ_date_naissance;
    private javax.swing.JTextField txt_AJ_nom;
    private javax.swing.JTextField txt_AJ_pays;
    private javax.swing.JTextField txt_AJ_prenom;
    private javax.swing.JTextField txt_AJ_ville;
    // End of variables declaration//GEN-END:variables
}
