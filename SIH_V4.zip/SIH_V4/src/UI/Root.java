package UI;

public class Root extends javax.swing.JFrame {
    public Root() {
        initComponents();
        this.setExtendedState(MAXIMIZED_BOTH); 
        this.setVisible(true);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txt_rt_id = new javax.swing.JTextField();
        txt_rt_mdp = new javax.swing.JTextField();
        but_rt_connection = new javax.swing.JButton();
        lbl_rt_icon = new javax.swing.JLabel();
        lbl_rt_font = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1920, 1080));
        getContentPane().setLayout(null);

        txt_rt_id.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        txt_rt_id.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(28, 138, 219)));
        txt_rt_id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_rt_idActionPerformed(evt);
            }
        });
        getContentPane().add(txt_rt_id);
        txt_rt_id.setBounds(1000, 500, 210, 30);

        txt_rt_mdp.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        txt_rt_mdp.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(28, 138, 219)));
        txt_rt_mdp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_rt_mdpActionPerformed(evt);
            }
        });
        getContentPane().add(txt_rt_mdp);
        txt_rt_mdp.setBounds(1000, 560, 210, 30);

        but_rt_connection.setFont(new java.awt.Font("Segoe UI Black", 0, 18)); // NOI18N
        but_rt_connection.setForeground(new java.awt.Color(0, 70, 149));
        but_rt_connection.setText("Se connecter");
        but_rt_connection.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        but_rt_connection.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                but_rt_connectionMouseClicked(evt);
            }
        });
        but_rt_connection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                but_rt_connectionActionPerformed(evt);
            }
        });
        getContentPane().add(but_rt_connection);
        but_rt_connection.setBounds(930, 710, 130, 30);

        lbl_rt_icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imageProjet/fondSIH.png"))); // NOI18N
        lbl_rt_icon.setMaximumSize(new java.awt.Dimension(1800, 850));
        lbl_rt_icon.setMinimumSize(new java.awt.Dimension(1800, 850));
        lbl_rt_icon.setPreferredSize(new java.awt.Dimension(1800, 850));
        getContentPane().add(lbl_rt_icon);
        lbl_rt_icon.setBounds(730, 250, 530, 430);

        lbl_rt_font.setBackground(new java.awt.Color(28, 138, 219));
        lbl_rt_font.setText("jLabel2");
        lbl_rt_font.setMaximumSize(new java.awt.Dimension(1800, 1000));
        lbl_rt_font.setMinimumSize(new java.awt.Dimension(1800, 1000));
        lbl_rt_font.setOpaque(true);
        lbl_rt_font.setPreferredSize(new java.awt.Dimension(1800, 1000));
        getContentPane().add(lbl_rt_font);
        lbl_rt_font.setBounds(-110, 0, 2080, 1030);

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void txt_rt_mdpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_rt_mdpActionPerformed
    }//GEN-LAST:event_txt_rt_mdpActionPerformed
    private void txt_rt_idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_rt_idActionPerformed
 
    }//GEN-LAST:event_txt_rt_idActionPerformed
    private void but_rt_connectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_but_rt_connectionActionPerformed
 
    }//GEN-LAST:event_but_rt_connectionActionPerformed
    private void but_rt_connectionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_but_rt_connectionMouseClicked
        this.dispose();
        FonctionsDonnees.nom_user=txt_rt_id.getText();
        new AccueilPH().setVisible(true);  
    }//GEN-LAST:event_but_rt_connectionMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Root.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Root.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Root.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Root.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Root().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton but_rt_connection;
    private javax.swing.JLabel lbl_rt_font;
    private javax.swing.JLabel lbl_rt_icon;
    private javax.swing.JTextField txt_rt_id;
    private javax.swing.JTextField txt_rt_mdp;
    // End of variables declaration//GEN-END:variables
}
