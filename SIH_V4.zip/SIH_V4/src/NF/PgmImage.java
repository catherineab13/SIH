package NF;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.*;
import java.util.*;
import javax.imageio.ImageIO;

/**
 * This class handles simple processing for PGM images The existing codes can
 * load and display a gray-scale image in PGM format It also contains an
 * implemented image processing method which flips the image horizontally. For
 * homework #1, you should only add new code inside this class without touching
 * any of the existing code. The new code includes: - Four new methods for 4
 * other simple image processing routines. - New code in the main method to
 * conduct user specified image manipulations
 */
public class PgmImage extends Component {
    // image buffer for graphical display

    private BufferedImage img;
    // image buffer for plain gray-scale pixel values
    private int[][] pixels;
    private int[][] hiddenPixels;

    // translating raw gray scale pixel values to buffered image for display
    private void pix2img() {
        int g;
        img = new BufferedImage(pixels[0].length, pixels.length, BufferedImage.TYPE_INT_ARGB);
        // copy the pixels values
        for (int row = 0; row < pixels.length; ++row) {
            for (int col = 0; col < pixels[row].length; ++col) {
                g = pixels[row][col];
                img.setRGB(col, row, ((255 << 24) | (g << 16) | (g << 8) | g));
            }
        }
        hiddenPixels = pixels.clone();
    }

    // default constructor with a 3 by 4 image
    public PgmImage() {
        int[][] defaultPixels = {{0, 1, 2, 3}, {4, 5, 6, 7}, {8, 9, 10, 11}};
        pixels = new int[defaultPixels.length][defaultPixels[0].length];
        for (int row = 0; row < pixels.length; ++row) {
            for (int col = 0; col < pixels[0].length; ++col) {
                pixels[row][col] = (int) (defaultPixels[row][col] * 255.0 / 12);
            }
        }
        pix2img();
    }

    // constructor that loads pgm image from a file
    public PgmImage(String filename) {
        pixels = null;
        readPGM(filename);
        if (pixels != null) {
            pix2img();
        }
    }

    // load gray scale pixel values from a PGM format image
    private void readPGM(String filename) {
        try {
            Scanner infile = new Scanner(new FileReader(filename));
            // process the top 4 header lines
            String filetype = infile.nextLine();
            if (!filetype.equalsIgnoreCase("p2")) {
                System.out.println("[readPGM]Cannot load the image type of " + filetype);
                return;
            }
            int cols = infile.nextInt();
            int rows = infile.nextInt();
            int maxValue = infile.nextInt();
            pixels = new int[rows][cols];
            System.out.println("Reading in image from " + filename + " of size " + rows + " by " + cols);
            // process the rest lines that hold the actual pixel values
            for (int r = 0; r < rows; r++) {
                for (int c = 0; c < cols; c++) {
                    pixels[r][c] = (int) (infile.nextInt() * 255.0 / maxValue);
                }
            }
            infile.close();
        } catch (FileNotFoundException fe) {
            System.out.println("Had a problem opening a file.");
        } catch (Exception e) {
            System.out.println(e.toString() + " caught in readPPM.");
            e.printStackTrace();
        }
    }
    // overrides the paint method of Component class

    public void paint(Graphics g) {
        // simply draw the buffered image
        g.drawImage(img, 0, 0, getWidth(), getHeight(), this);
    }
    // overrides the method in Component class, to determine the window size

    public Dimension getPreferredSize() {
        if (img == null) {
            return new Dimension(100, 100);
        } else {
            // make sure the window is not two small to be seen
            return new Dimension(Math.max(100, img.getWidth(null)),
                    Math.max(100, img.getHeight(null)));
        }
    }

    //Ajouter un Patient à la BDD
    static public void ajouterImageaBDD(String path) {
        try {
            File image = new File(path);
            FileInputStream fis = new FileInputStream(image);

            

            
            //Connection à la base de données
            String url = "jdbc:mysql://mysql-healthview.alwaysdata.net:3306/healthview_pacs?zeroDateTimeBehavior=convertToNull";
            Connection cn = DriverManager.getConnection(url, "152416_sir", "projetsir2018");
            //Créer declaration 
            Statement dec = cn.createStatement();
            //Ajouter un DMR à la base de données
            String requeteAjout = "INSERT INTO Image (idImage, imagenum) VALUES (?,?)";
            ResultSet re_ind = dec.executeQuery("select max(idImage) from Image");
            re_ind.next();
            int nouvelIndice = re_ind.getInt(1)+1;
            PreparedStatement pst = cn.prepareStatement(requeteAjout);
            pst.setString(1,Integer.toString(nouvelIndice));
            pst.setBinaryStream(2, fis, (int) image.length());
            pst.execute();
            dec.executeLargeUpdate(requeteAjout);
            System.out.println("Ajout Image Réussi");
        } 
        catch (SQLException excSQL) {
            System.out.println("Ajout Image Réussi");}
        catch (FileNotFoundException excFile){
            System.out.println("Ajout Image Impossible");
            excFile.printStackTrace();
        }
}

    static public void rechercherImageDansBDD(String idImage_rech) throws SQLException, IOException {
        try {
        //connection à la base de données
        String url = "jdbc:mysql://mysql-healthview.alwaysdata.net:3306/healthview_pacs?zeroDateTimeBehavior=convertToNull";
        Connection cn = DriverManager.getConnection(url, "152416_sir", "projetsir2018");
        //creer declaration 
        Statement dec = cn.createStatement();
        //requete recuperation patient
        ResultSet re_img = dec.executeQuery("SELECT imagenum FROM Image WHERE idImage=" + "'" + idImage_rech + "'");

        re_img.next();
        //Renseignement Image
        Blob blob = re_img.getBlob("imagenum");
        System.out.println("Patient trouvé dans BDD");
        BufferedInputStream image = new BufferedInputStream(blob.getBinaryStream());
        BufferedImage raw = ImageIO.read(image);
        JFrame fenetre = new JFrame("Test");
        fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JLabel test = new JLabel(new ImageIcon(raw));
        fenetre.add(test);
        fenetre.pack();
        fenetre.setVisible(true);
        } catch (Exception exc) {
            System.out.println("Le patient n'a pas été trouvé dans la base de données");
        }
    }

    /**
     * flipH: Flip the image in horizontal direction
     */
    private void flipH() {
        int tmp, sym;
        for (int row = 0; row < pixels.length; ++row) {
            for (int col = 0; col < pixels[row].length / 2; ++col) {
                // find the column index of the horizontally symmetric pixel
                sym = pixels[row].length - 1 - col;
                // swap the pixel value between the two
                tmp = pixels[row][col];
                pixels[row][col] = pixels[row][sym];
                pixels[row][sym] = tmp;
            }
        }
        this.pix2img();
    }

    /**
     * flipV: Flip the image in vertical direction
     */
    private void flipV() {
        int tmp;
        for (int row = 0; row < pixels[0].length / 2; row++) {
            for (int col = 0; col < pixels.length; col++) {
                // swap the pixel value between the two
                tmp = pixels[row][col];
                pixels[row][col] = pixels[pixels[0].length - row - 1][col];
                pixels[pixels[0].length - row - 1][col] = tmp;
            }
        }
        this.pix2img();
    }

    private void transpose() {

        for (int row = 0; row < pixels.length; row++) {
            for (int col = row; col < pixels[0].length; col++) {
                int tmp = pixels[row][col];
                pixels[row][col] = pixels[col][row];
                pixels[col][row] = tmp;
            }
        }

        this.pix2img();
    }

    /**
     * Rotates the image in clockwise direction.
     *
     * @param image the image to be rotated.
     * @returns the rotated image.
     * @throws NPE
     */
    private void rotateClockWise() {

        transpose();

        // swap columns
        for (int col = 0; col < pixels[0].length / 2; col++) {
            for (int row = 0; row < pixels.length; row++) {
                int tmp = pixels[row][col];
                pixels[row][col] = pixels[row][pixels[0].length - 1 - col];
                pixels[row][pixels[0].length - 1 - col] = tmp;
            }
        }

        this.pix2img();
    }

    private void rotateAntiClockWise() {

        // transpose
        transpose();

        //  swap rows
        for (int row = 0; row < pixels.length / 2; row++) {
            for (int col = 0; col < pixels[0].length; col++) {
                int tmp = pixels[row][col];
                pixels[row][col] = pixels[pixels.length - 1 - row][col];
                pixels[pixels.length - 1 - row][col] = tmp;
            }
        }

        this.pix2img();
    }

    private void contrast(int value) {
        for (int row = 0; row < pixels.length; ++row) {
            for (int col = 0; col < pixels[row].length; ++col) {
                hiddenPixels[col][row] = pixels[col][row] + value;
                if (hiddenPixels[col][row] < 0) {
                    pixels[col][row] = 0;
                } else if (hiddenPixels[col][row] > 255) {
                    pixels[col][row] = 255;
                }
            }
        }
        this.pix2img();
    }

    private void contrastInversion() {
        for (int row = 0; row < pixels.length; ++row) {
            for (int col = 0; col < pixels[row].length; ++col) {
                pixels[col][row] = 255 - pixels[col][row];
            }
        }
        this.pix2img();
    }

    private void annotation(String s1, String s2) {

        Graphics2D g2d = (Graphics2D) img.getGraphics();
        g2d.setFont(new Font("Serif", Font.PLAIN, 12));
        g2d.setColor(Color.WHITE);
        g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g2d.drawString(s1, 0, pixels.length - 16);
        g2d.drawString(s2, 0, pixels.length - 3);
        g2d.dispose();

        try (OutputStream out = new FileOutputStream("C:\\Users\\ilian\\Desktop\\cor494-i43.png")) {
            ImageIO.write(img, "png", out);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    // The main method that will load and process a pgm image, and display the result.

    public static void main(String[] args) {
        // instantiate the PgmImage object according to the 
        //  command line argument
        PgmImage img;
        String filename = "default";
        String operation = "none";
        String value = "";
        String line1 = "";
        String line2 = "";

        if (args.length > 1) {
            operation = args[1];
            if ((operation.length() > 8) && (operation.substring(0, 8).equals("contrast"))) {
                value += operation.substring(8);
                operation = operation.substring(0, 8);
            } else if (operation.contains("+")) {
                line1 += operation.substring(0, operation.indexOf("+"));
                line2 += operation.substring(operation.indexOf("+") + 1);
            }
        }
        if (args.length > 0) {
            filename = args[0];
            img = new PgmImage(filename);
        } else {
            img = new PgmImage();
            filename = "default";
        }

        /**
         * *************************************************
         * Apply preferred image processing here:
         * ************************************************
         */
        if (operation.equalsIgnoreCase("flipH")) {
            img.flipH();
        } else if (operation.equalsIgnoreCase("flipV")) {
            img.flipV();
        } else if (operation.equalsIgnoreCase("rotate")) {
            img.rotateClockWise();
        } else if (operation.equalsIgnoreCase("antiRotate")) {
            img.rotateAntiClockWise();
        } else if (operation.equalsIgnoreCase("contrast")) {
            if (value.equals("Inversion")) {
                img.contrastInversion();
            } else {
                img.contrast(Integer.valueOf(value));
            }
        } else {
            img.annotation(line1, line2);
        }
        // set up the GUI for display the PgmImage object 
        JFrame f = new JFrame("PGM Image: " + filename + " Image Operation: " + operation);
        f.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
        f.add(img);
        f.pack();
        f.setVisible(true);
    }
}
