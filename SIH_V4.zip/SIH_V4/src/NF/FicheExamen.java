package NF;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class FicheExamen {

    private int idExam;
    private String dateExamen;
    private String typeImage;
    private FichePH phRespo;
    private FichePatient patient;
    private String remarque;
    private String compteRendu;

//Formats Examen
    //Format examen full
    public FicheExamen(int idExam, String typeImage, String dateExamen,FichePH phRespo, FichePatient patient, String remarque, String compteRendu) {
        this.idExam = idExam;
        this.typeImage = typeImage;
        this.dateExamen = dateExamen;
        this.phRespo=phRespo;
        this.patient = patient;
        this.remarque = remarque;
        this.compteRendu = compteRendu;
    }

    //Format examen without compterendu
    public FicheExamen(int idExam,String typeImage, String dateExamen, FichePH phRespo, FichePatient patient, String remarque) {
        this.typeImage = typeImage;
        this.dateExamen = dateExamen;
        this.phRespo=phRespo;
        this.patient = patient;
        this.remarque = remarque;
    }

    //Format examen reduit
    public FicheExamen(int idExam,String typeImage, String dateExamen, FichePH phRespo, FichePatient patient) {
        this.idExam =idExam;
        this.typeImage = typeImage;
        this.dateExamen = dateExamen;
        this.phRespo=phRespo;
        this.patient = patient;
        this.remarque = null;
        this.compteRendu = null;
    }

    //Format examen vide
    public FicheExamen() {
        this.idExam = 0;
        this.typeImage = null;
        this.dateExamen = null;
        this.phRespo=phRespo;
        this.patient = null;
        this.remarque = null;
        this.compteRendu = null;
    }

// Fonctions Examen



//    public void addExamen() {
//        try {
//            //connection à la base de données
//            String url = "jdbc:mysql://mysql-healthview.alwaysdata.net:3306/healthview_sir?zeroDateTimeBehavior=convertToNull";
//            Connection cn = DriverManager.getConnection(url, "152416_sir", "projetsir2018");
//
//            //creer declaration 
//            Statement dec = cn.createStatement();
//
//            String requeteAddExamen = "Insert INTO 'Examens' ('idExamens','date','type','PHradio_idPHradio','Patients_idPatient',) values (NULL ,'" + this.getDateExamen() + "' ,'" + this.getTypeImage() + "' ,'" + this.trouveridPH() + "' ,'" + this.trouveridPatient() + "')";
//            dec.executeLargeUpdate(requeteAddExamen);
//            String requeteRem = "Insert INTO 'ResultatExamen'('idResultatExam', 'compte_rendu', 'remarqueExamen') VALUES ('NULL','','" + this.getRemarque() + "')";
//            dec.executeLargeUpdate(requeteRem);
//            System.out.println("Ajout effectué");
//
//        } catch (Exception exc) {
//            exc.printStackTrace();
//        }
//    }

//Trouver les infos examens associés à un PH
    static public ArrayList<FicheExamen> trouverInfosExamensPH(FichePH phRespo) {
        ArrayList<FicheExamen> listeExaPH = new ArrayList<FicheExamen>();
        int id_exam_a_rech = 0;
        String typeImage_a_rech = null;
        String date_exam_a_rech = null;
        FichePatient pat_a_rech=null;
        int id_phRespo=FichePH.trouveridPH(phRespo.getNomPHRespo(),phRespo.getPrenomPHRespo());
        phRespo=new FichePH(phRespo.getNomPHRespo().toUpperCase(),phRespo.getPrenomPHRespo().toUpperCase());
        int id_pat_a_rech = 0;

        try {
            //connection à la base de données
            String url = "jdbc:mysql://mysql-healthview.alwaysdata.net:3306/healthview_sir?zeroDateTimeBehavior=convertToNull";
            Connection cn = DriverManager.getConnection(url, "152416_sir", "projetsir2018");

            //creer declaration 
            Statement dec = cn.createStatement();

            String requeteFi = "select * from Examens where Examens.PHradio_idPHradio='" + id_phRespo + "'";
            ResultSet rec_fi = dec.executeQuery(requeteFi);

            while (rec_fi.next()) {
                id_exam_a_rech = (rec_fi.getInt("idExamens"));
                typeImage_a_rech = (rec_fi.getString("type"));
                date_exam_a_rech = (rec_fi.getString("date"));
                id_pat_a_rech=(rec_fi.getInt("Patients_idPatient"));
                pat_a_rech=FichePatient.rechercherPatient(id_pat_a_rech);
                listeExaPH.add(new FicheExamen(id_exam_a_rech,typeImage_a_rech, date_exam_a_rech,phRespo, pat_a_rech));
            }

        } catch (Exception exc) {
            exc.printStackTrace();

        }
        return listeExaPH;

    }
    
//Trouver les infos examens associés à un patient 
    static public ArrayList<FicheExamen> trouverInfosExamensPatient(FichePatient pat) {
        ArrayList<FicheExamen> listeExaPatient = new ArrayList<FicheExamen>();
        int id_exam_a_rech = 0;
        String typeImage_a_rech = null;
        String date_exam_a_rech = null;
        int id_phRespo_a_rech=0;
        FichePH phRespo_a_rech=null;
        int id_pat_a_rech = pat.trouveridPatient(pat.getNom(), pat.getPrenom(), pat.getDateDeNaissance());
        pat=new FichePatient(pat.getNom().toUpperCase(),pat.getPrenom().toUpperCase(),pat.getDateDeNaissance());
        
        try {
            //connection à la base de données
            String url = "jdbc:mysql://mysql-healthview.alwaysdata.net:3306/healthview_sir?zeroDateTimeBehavior=convertToNull";
            Connection cn = DriverManager.getConnection(url, "152416_sir", "projetsir2018");

            //creer declaration 
            Statement dec = cn.createStatement();

            String requeteFi = "select * from Examens where Examens.Patients_idPatient='" + id_pat_a_rech + "'";
            ResultSet rec_fi = dec.executeQuery(requeteFi);

            while (rec_fi.next()) {
                id_exam_a_rech = (rec_fi.getInt("idExamens"));
                typeImage_a_rech = (rec_fi.getString("type"));
                date_exam_a_rech = (rec_fi.getString("date"));
                id_phRespo_a_rech=(rec_fi.getInt("PHradio_idPHradio"));
                phRespo_a_rech=FichePH.rechercherPH(id_phRespo_a_rech);
                listeExaPatient.add(new FicheExamen(id_exam_a_rech,typeImage_a_rech, date_exam_a_rech,phRespo_a_rech,pat));
            }

        } catch (Exception exc) {
            exc.printStackTrace();

        }
        return listeExaPatient;

    }
    
    public void commenterUnActe(String commentaire) {
        try {
            //connection à la base de données
            String url = "jdbc:mysql://mysql-healthview.alwaysdata.net:3306/healthview_sir?zeroDateTimeBehavior=convertToNull";
            Connection cn = DriverManager.getConnection(url, "152416_sir", "projetsir2018");

            //creer declaration 
            Statement dec = cn.createStatement();
            String requeteModif = "UPDATE 'ResultatExamen' SET compte_rendu = '" + commentaire + "' WHERE 'ResultatExamen.idResultatExam'=" + this.getNumeroExamen();
            dec.executeLargeUpdate(requeteModif);
            System.out.println("Mise à jour effectuée");
        } catch (Exception exc) {
            exc.printStackTrace();

        }
    }

// Fonctions Set & Get
    public int getNumeroExamen() {
        return idExam;
    }

    public String getTypeImage() {
        return typeImage;
    }

    public String getDateExamen() {
        return dateExamen;
    }

    public FichePH getPHRespo() {
        return phRespo;
    }


    public FichePatient getPatient() {
        return patient;
    }

    public String getRemarque() {
        return remarque;
    }

    public String getCompteRendu() {
        return compteRendu;
    }
    

    public void setNumeroExamen(int idExam) {
        this.idExam = idExam;
    }

    public void setTypeImage(String typeImage) {
        this.typeImage = typeImage;
    }

    public void setDateExamen(String dateExamen) {
        this.dateExamen = dateExamen;
    }

    public void setPHRespo(FichePH phRespo) {
        this.phRespo = phRespo;
    }

    public void setPatient(FichePatient patient) {
        this.patient = patient;
    }

    public void setRemarque(String remarque) {
        this.remarque = remarque;
    }

    public void setCompteRendu(String compteRendu) {
        this.compteRendu = compteRendu;
    }

    
    
}
