package NF;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {

    public static void main(String[] args) {
////        DMR dossierNumero1 = new DMR("blanchard", "robin", "1996-12-01", "14, rue du trou de balle", "Sainte-Iliana-sur-Mer", 69666, "République très très très très très très très très très démocratique du chalet", "F", 1);
////        System.out.println(dossierNumero1.getPatient().getNom());
////        System.out.println(dossierNumero1.getPatient().getPrenom());
////        System.out.println(dossierNumero1.getPatient().getDateDeNaissance());
////        System.out.println(dossierNumero1.getDomicile().getAdresse());
////        System.out.println(dossierNumero1.getDomicile().getVille());
////        System.out.println(dossierNumero1.getDomicile().getCodePostal());
////        System.out.println(dossierNumero1.getDomicile().getPays());
////        System.out.println(dossierNumero1.getGenre());
////        System.out.println(dossierNumero1.getId());
////Image image = new Image("C:\\Users\\ilian\\Desktop\\Ducky Thug.png");
//
//        FicheExamen fiche = new FicheExamen();
//
//        ArrayList<FicheExamen> fichesExamPat = fiche.trouverInfosExamensPatient(new FichePatient("wayne", "bruce", "H", "2000-01-01"));
//
////        System.out.println("Fiche Exam Patient");
////        System.out.println("************************************************************************************");
////
////        for (int i = 0; i < fichesExamPat.size(); i++) {
////            System.out.println("Nom patient : " + fichesExamPat.get(i).getPatient().getNom());
////            System.out.println("Date examen : " + fichesExamPat.get(i).getDateExamen());
////            System.out.println("Nom PHRespo: " + fichesExamPat.get(i).getPHRespo().getNomPHRespo());
////            System.out.println("");
////        }
//        
//        System.out.println(fichesExamPat.size());
//
//        ArrayList<FicheExamen> fichesExamPH = fiche.trouverInfosExamensPH(new FichePH("cuddy", "lisa"));
//  
////        System.out.println("Fiche Exam PH");
////        System.out.println("************************************************************************************");
////        for (int i = 0; i < fichesExamPH.size(); i++) {
////            System.out.println("Date d'exam : " + fichesExamPH.get(i).getDateExamen());
////            System.out.println("Nom PH Respo: " + fichesExamPH.get(i).getPHRespo().getNomPHRespo());
////            System.out.println("Prenom PH Respo: " + fichesExamPH.get(i).getPHRespo().getPrenomPHRespo());
////            System.out.println("Type Image: " + fichesExamPH.get(i).getTypeImage());
////            System.out.println("Nom Patient : " + fichesExamPH.get(i).getPatient().getNom());
////            System.out.println();
////
////        }
//        
//        System.out.println(fichesExamPH.size());
        
//        PgmImage.main(new String[]{"C:\\Users\\ilian\\Desktop\\cor494-i43.pgm"});
//        PgmImage.main(new String[]{"C:\\Users\\ilian\\Desktop\\cor494-i43.pgm","flipH"});
//        PgmImage.main(new String[]{"C:\\Users\\ilian\\Desktop\\cor494-i43.pgm","flipV"});
//        PgmImage.main(new String[]{"C:\\Users\\ilian\\Desktop\\cor494-i43.pgm","rotate"});
//        PgmImage.main(new String[]{"C:\\Users\\ilian\\Desktop\\cor494-i43.pgm","antiRotate"});
//        PgmImage.main(new String[]{"C:\\Users\\ilian\\Desktop\\cor494-i43.pgm","contrast50"});
//        PgmImage.main(new String[]{"C:\\Users\\ilian\\Desktop\\cor494-i43.pgm","contrast-50"});
//        PgmImage.main(new String[]{"C:\\Users\\ilian\\Desktop\\cor494-i43.pgm","contrastInversion"});
//        PgmImage.main(new String[]{"C:\\Users\\ilian\\Desktop\\cor494-i43.pgm","Test d'annotation. Vous pouvez ajouter ce que+vous voulez en dessous de l'image"});
        
//        PgmImage.ajouterImageaBDD("C:\\Users\\ilian\\Desktop\\cor494-i43.png");
        try {
            PgmImage.rechercherImageDansBDD("2");
        } catch (Exception ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
