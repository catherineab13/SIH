package NF;

import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class FichePatient {
    
    private int id;
    private String nom;
    private String prenom;
    private String genre; 
    private String dateDeNaissance;
    private String adresse;
    private String ville;
    private int codePostal;
    private String pays;

//Formats Patient
    //Format patient full
    public FichePatient(int id, String nom, String prenom, String genre, String dateDeNaissance, String adresse, String ville, int codePostal, String pays) {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.genre = genre;
        this.dateDeNaissance = dateDeNaissance;
        this.adresse = adresse;
        this.ville = ville;
        this.codePostal = codePostal;
        this.pays = pays;
    }
    
    //Format patient reduit
    public FichePatient(String nom, String prenom, String date){
        this.nom = nom;
        this.prenom = prenom;
        this.dateDeNaissance = date;
        this.adresse=null;
        this.ville=null;
        this.codePostal=0;
        this.pays=null;
    }
    
    //Format patient reduit exam
    public FichePatient(String nom, String prenom,String genre, String date){
        this.nom = nom;
        this.prenom = prenom;
        this.genre=genre;
        this.dateDeNaissance = date;
        this.adresse=null;
        this.ville=null;
        this.codePostal=0;
        this.pays=null;
    }
    
    //Format patient vide
    public FichePatient(){
        this.nom = null;
        this.prenom = null;
        this.dateDeNaissance = null;
        this.adresse=null;
        this.ville=null;
        this.codePostal=0;
        this.pays=null;
    }

//Fonctions Patient
    //Ajouter un Patient à la BDD
    public void ajouterPatientaBDD() {
        try {
            //Connection à la base de données
            String url = "jdbc:mysql://mysql-healthview.alwaysdata.net:3306/healthview_sir?zeroDateTimeBehavior=convertToNull";
            Connection cn = DriverManager.getConnection(url, "152416_sir", "projetsir2018");
            //Créer declaration 
            Statement dec = cn.createStatement();
            //Ajouter un DMR à la base de données
            String requeteAjout = "INSERT INTO Patients (idPatient, nom, prenom, date_naissance, genre, adresse, ville, code_postal, pays) VALUES (NULL, '" + this.getNom() + "', '" + this.getPrenom() + "', '" + this.getDateDeNaissance() + "', '" + this.getGenre() + "', '" + this.getAdresse() + "', '" + this.getVille() + "', '" + this.getCodePostal() + "', '" + this.getPays() + "')";
            dec.executeLargeUpdate(requeteAjout);
            System.out.println("Ajout Patient Réussi");
        } 
        catch (Exception exc) {
            System.out.println("Ajout Patient Impossible");
            exc.printStackTrace();
        }
    }
    
    //Rechercher un Patient dans la BDD with nom, prenom, date_naissance
    static public FichePatient rechercherPatient(String nom_rech, String prenom_rech, String date_naissance_rech){
        FichePatient pat_rechBDD=new FichePatient();
        try {
            //connection à la base de données
            String url = "jdbc:mysql://mysql-healthview.alwaysdata.net:3306/healthview_sir?zeroDateTimeBehavior=convertToNull";
            Connection cn = DriverManager.getConnection(url, "152416_sir", "projetsir2018");
            //creer declaration 
            Statement dec = cn.createStatement();
            //requete recuperation patient
            String requeteRecherchePatient = "select * from Patients where Patients.nom=" + "'" + nom_rech + "'" + " AND Patients.prenom=" + "'" + prenom_rech + "'" + "AND Patients.date_naissance=" + "'" + date_naissance_rech + "'";
            ResultSet re_pat = dec.executeQuery(requeteRecherchePatient);
            //Renseigneent Patient
            int idP = 0;
            String nomP = null;
            String prenomP = null;
            String genreP = null;
            String date_naissanceP = null;
            String adresseP = null;
            String villeP = null;
            int code_postalP = 0;
            String paysP = null;
            while (re_pat.next()) {
                idP = re_pat.getInt("idPatient");
                nomP = re_pat.getString("nom");
                prenomP = re_pat.getString("prenom");
                genreP = re_pat.getString("genre");
                date_naissanceP = re_pat.getString("date_naissance");
                adresseP = re_pat.getString("adresse");
                villeP = re_pat.getString("ville");
                code_postalP = re_pat.getInt("code_postal");
                paysP = re_pat.getString("pays");
            }
            System.out.println("Patient trouvé dans BDD");
            return pat_rechBDD = new FichePatient(idP, nomP, prenomP, genreP, date_naissanceP, adresseP, villeP, code_postalP, paysP);
        } 
        catch (Exception exc) {
            System.out.println("Patient pas trouvé dans BDD"); 
            return pat_rechBDD=new FichePatient();
        }
    }
    
    //Rechercher un Patient dans la BDD with id
    static public FichePatient rechercherPatient(int id_pat){
        FichePatient pat_rechBDD=new FichePatient();
        try {
            //connection à la base de données
            String url = "jdbc:mysql://mysql-healthview.alwaysdata.net:3306/healthview_sir?zeroDateTimeBehavior=convertToNull";
            Connection cn = DriverManager.getConnection(url, "152416_sir", "projetsir2018");
            
            //creer declaration 
            Statement dec = cn.createStatement();
            //requete recuperation patient
            String requeteRecherchePatient = "select * from Patients where Patients.idPatient=" + "'" + id_pat + "'";
            ResultSet re_pat = dec.executeQuery(requeteRecherchePatient);
            
            //Renseignement Patient
            String nomP = null;
            String prenomP = null;
            String genreP = null;
            String date_naissanceP = null;
            String adresseP = null;
            String villeP = null;
            int code_postalP = 0;
            String paysP = null;
            
            while (re_pat.next()) {
                nomP = re_pat.getString("nom");
                prenomP = re_pat.getString("prenom");
                genreP = re_pat.getString("genre");
                date_naissanceP = re_pat.getString("date_naissance");
                adresseP = re_pat.getString("adresse");
                villeP = re_pat.getString("ville");
                code_postalP = re_pat.getInt("code_postal");
                paysP = re_pat.getString("pays");
            }
            return pat_rechBDD = new FichePatient(id_pat, nomP, prenomP, genreP, date_naissanceP, adresseP, villeP, code_postalP, paysP);
        } 
        catch (Exception exc) {
            System.out.println("Patient pas trouvé dans BDD"); 
            return pat_rechBDD=new FichePatient();
        }
    }
    
     //Rechercher un Patient dans la BDD with id reduced
    static public FichePatient rechercherPatientReduit(int id_pat){
        FichePatient pat_rechBDD=new FichePatient();
        try {
            //connection à la base de données
            String url = "jdbc:mysql://mysql-healthview.alwaysdata.net:3306/healthview_sir?zeroDateTimeBehavior=convertToNull";
            Connection cn = DriverManager.getConnection(url, "152416_sir", "projetsir2018");
            //creer declaration 
            Statement dec = cn.createStatement();
            //requete recuperation patient
            String requeteRecherchePatient = "select * from Patients where Patients.id=" + "'" + id_pat + "'";
            ResultSet re_pat = dec.executeQuery(requeteRecherchePatient);
            //Renseigneent Patient
            int idP = 0;
            String nomP = null;
            String prenomP = null;
            String genreP = null;
            String date_naissanceP = null;
        
            while (re_pat.next()) {
                idP = re_pat.getInt("idPatient");
                nomP = re_pat.getString("nom");
                prenomP = re_pat.getString("prenom");
                genreP = re_pat.getString("genre");
                date_naissanceP = re_pat.getString("date_naissance");
            }
            System.out.println("Patient trouvé dans BDD");
            return pat_rechBDD = new FichePatient(nomP, prenomP, genreP, date_naissanceP);
        } 
        catch (Exception exc) {
            System.out.println("Patient pas trouvé dans BDD"); 
            return pat_rechBDD=new FichePatient();
        }
    }
      
    
    //Trouver l'id d'un patient
    static public int trouveridPatient(String nom,String prenom, String date_naissance) {
        int id = 0;
        try {
            //connection à la base de données
            String url = "jdbc:mysql://mysql-healthview.alwaysdata.net:3306/healthview_sir?zeroDateTimeBehavior=convertToNull";
            Connection cn = DriverManager.getConnection(url, "152416_sir", "projetsir2018");

            //creer declaration 
            Statement dec = cn.createStatement();

            String requeteRecherchePatient = "select * from Patients where Patients.nom=" + "'" + nom + "'" + " AND Patients.prenom=" + "'" + prenom + "'" + "AND Patients.date_naissance=" + "'" + date_naissance + "'";
            ResultSet re_pat = dec.executeQuery(requeteRecherchePatient);
     

            while (re_pat.next()) {
                id = re_pat.getInt("idPatient");
            }

        } catch (Exception exc) {
            exc.printStackTrace();
        }
        return id;
    }
    
//Fonctions Set & Get
    public String getGenre() {
        return genre;
    }
    
    public void setGenre(String genre) {
        this.genre = genre;
    }

    /**
     * @return the nom
     */
    public String getNom() {
        return nom;
    }

    /**
     * @param nom the nom to set
     */
    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     * @return the prenom
     */
    public String getPrenom() {
        return prenom;
    }

    /**
     * @param prenom the prenom to set
     */
    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    /**
     * @return the dateDeNaissance
     */
    public String getDateDeNaissance() {
        return dateDeNaissance;
    }

    /**
     * @param dateDeNaissance the dateDeNaissance to set
     */
    public void setDateDeNaissance(String dateDeNaissance) {
        this.dateDeNaissance = dateDeNaissance;
    }
    
    /**
     * @return the adresse
     */
    public String getAdresse() {
        return adresse;
    }

    /**
     * @param adresse the adresse to set
     */
    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    /**
     * @return the ville
     */
    public String getVille() {
        return ville;
    }

    /**
     * @param ville the ville to set
     */
    public void setVille(String ville) {
        this.ville = ville;
    }

    /**
     * @return the codePostal
     */
    public int getCodePostal() {
        return codePostal;
    }

    /**
     * @param codePostal the codePostal to set
     */
    public void setCodePostal(int codePostal) {
        this.codePostal = codePostal;
    }

    /**
     * @return the pays
     */
    public String getPays() {
        return pays;
    }

    /**
     * @param pays the pays to set
     */
    public void setPays(String pays) {
        this.pays = pays;
    }    
}