package NF;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author robin
 */
public class Acces {

    String identifiant;
    String mdp;
    String fonction;

    public Acces() {
    }

    public String getIdentifiant() {
        return identifiant;
    }

    public void setIdentifiant(String identifiant) {
        this.identifiant = identifiant;
    }

    public String getMdp() {
        return mdp;
    }

    public void setMdp(String mdp) {
        this.mdp = mdp;
    }

    public String getFonction() {
        return fonction;
    }

    public void setFonction(String fonction) {
        this.fonction = fonction;
    }

    public Acces trouverAcces(String id, String mp) {
        Acces enter = new Acces();

        try {
            //connection à la base de données
            String url = "jdbc:mysql://mysql-healthview.alwaysdata.net:3306/healthview_sir?zeroDateTimeBehavior=convertToNull";
            Connection cn = DriverManager.getConnection(url, "152416_sir", "projetsir2018");

            //creer declaration 
            Statement dec = cn.createStatement();

            String requeteCompte = "select COUNT(*) from Acces where Patients.identifiant=" + "'" + id + "'" + " AND Acces.mdp=" + "'" + mp + "'";
            ResultSet re_ac = dec.executeQuery(requeteCompte);

            int ligne = 0;

            while (re_ac.next()) {
                ligne = re_ac.getInt(1);
            }
            if (ligne != 0) {
                String requeteAcces = "select COUNT(*) from Acces where Patients.identifiant=" + "'" + id + "'" + " AND Acces.mdp=" + "'" + mp + "'";
                ResultSet re_acc = dec.executeQuery(requeteAcces);

                String fnt = null;
                while (re_acc.next()) {
                    fnt = re_acc.getString("fonction");
                }

                enter.setFonction(fnt);
                enter.setIdentifiant(id);
                enter.setMdp(mp);

            }
            

        } catch (Exception exc) {
            exc.printStackTrace();

        }
        return enter;
    }
}
