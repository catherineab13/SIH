/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NF;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author ilian
 */
public class FichePH {
        private int idPHRespo;
        private String nomPHRespo;
        private String prenomPHRespo;

//Format PH
        //Format PH full
        public FichePH(int idPHRespo,String nomPHRespo,String prenomPHRespo){
            this.idPHRespo=idPHRespo;
            this.nomPHRespo=nomPHRespo;
            this.prenomPHRespo=prenomPHRespo;
        }
    
        //Format PH réduit
        public FichePH(String nomPHRespo,String prenomPHRespo){
            this.idPHRespo=0;
            this.nomPHRespo=nomPHRespo;
            this.prenomPHRespo=prenomPHRespo;
        }
    
        //Format PH vide
        public FichePH(){
            this.idPHRespo=0;
            this.nomPHRespo=null;
            this.prenomPHRespo=null;
        }
        
    
 
        static public int trouveridPH(String nomPHRespo_a_rech, String prenomPHRespo_a_rech) {
        int id = 0;

        try {
            //connection à la base de données
            String url = "jdbc:mysql://mysql-healthview.alwaysdata.net:3306/healthview_sir?zeroDateTimeBehavior=convertToNull";
            Connection cn = DriverManager.getConnection(url, "152416_sir", "projetsir2018");

            //creer declaration 
            Statement dec = cn.createStatement();

            String requetePH = "select idPHradio from PHradio where PHradio.nomPH='" + nomPHRespo_a_rech + "' AND PHradio.prenomPH='" + prenomPHRespo_a_rech + "'";
            ResultSet re_id = dec.executeQuery(requetePH);
            while (re_id.next()) {
                id = re_id.getInt("idPHradio");
            }

        } catch (Exception exc) {
            exc.printStackTrace();

        }
        return id;

    }

    static public String trouverNomPH(int num_ph_a_rech) {
        String nom_a_rech = null;

        try {
            //connection à la base de données
            String url = "jdbc:mysql://mysql-healthview.alwaysdata.net:3306/healthview_sir?zeroDateTimeBehavior=convertToNull";
            Connection cn = DriverManager.getConnection(url, "152416_sir", "projetsir2018");

            //creer declaration 
            Statement dec = cn.createStatement();

            String requetePH = "select nomPH from PHradio where PHradio.idPHradio='" + num_ph_a_rech + "'";
            ResultSet re_nom = dec.executeQuery(requetePH);
            while (re_nom.next()) {
                nom_a_rech = re_nom.getString("nomPH");
            }

        } catch (Exception exc) {
            exc.printStackTrace();

        }
        return nom_a_rech;

    }

    static public String trouverPrenomPH(int num_ph_a_rech) {
        String prenom_a_rech = null;

        try {
            //connection à la base de données
            String url = "jdbc:mysql://mysql-healthview.alwaysdata.net:3306/healthview_sir?zeroDateTimeBehavior=convertToNull";
            Connection cn = DriverManager.getConnection(url, "152416_sir", "projetsir2018");

            //creer declaration 
            Statement dec = cn.createStatement();

            String requetePH = "select prenomPH from PHradio where PHradio.idPHradio='" + num_ph_a_rech + "'";
            
            ResultSet re_prenom = dec.executeQuery(requetePH);
            while (re_prenom.next()) {
                prenom_a_rech = re_prenom.getString("prenomPH");
            }

        } catch (Exception exc) {
            exc.printStackTrace();

        }
        return prenom_a_rech;
    }
    
     //Rechercher un Patient dans la BDD with id
    static public FichePH rechercherPH(int id_PH){
        FichePH ph_rechBDD=new FichePH();
        try {
            //connection à la base de données
            String url = "jdbc:mysql://mysql-healthview.alwaysdata.net:3306/healthview_sir?zeroDateTimeBehavior=convertToNull";
            Connection cn = DriverManager.getConnection(url, "152416_sir", "projetsir2018");
            
            //creer declaration 
            Statement dec = cn.createStatement();
            //requete recuperation patient
            String requeteRecherchePH = "select * from PHradio where PHradio.idPHradio=" + "'" + id_PH + "'";
            ResultSet re_pat = dec.executeQuery(requeteRecherchePH);
            
            //Renseignement Patient
            String nomPH = null;
            String prenomPH = null;
            
            while (re_pat.next()) {
                nomPH = re_pat.getString("nomPH");
                prenomPH = re_pat.getString("prenomPH");
            }
            return ph_rechBDD = new FichePH(id_PH, nomPH, prenomPH);
        } 
        catch (Exception exc) {
            System.out.println("Patient pas trouvé dans BDD"); 
            return ph_rechBDD=new FichePH();
        }
    }
    

    public int getIdPHRespo() {
        return idPHRespo;
    }

    public String getNomPHRespo() {
        return nomPHRespo;
    }

    public String getPrenomPHRespo() {
        return prenomPHRespo;
    }

    public void setIdPHRespo(int idPHRespo) {
        this.idPHRespo = idPHRespo;
    }

    public void setNomPHRespo(String nomPHRespo) {
        this.nomPHRespo = nomPHRespo;
    }

    public void setPrenomPHRespo(String prenomPHRespo) {
        this.prenomPHRespo = prenomPHRespo;
    }
    
    
    
}
