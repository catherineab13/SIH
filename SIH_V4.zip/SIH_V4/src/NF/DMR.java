package NF;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

public class DMR {

    /*
    crée le dossier medical radiologique :
        5 privates en dessous
     */
    private FichePatient patient;
    private List fichesExamen = new ArrayList<FicheExamen>();

    public DMR() {
    }

    public DMR(FichePatient patient, List FichesExamen) throws ParseException {
        this.patient = patient;
    }

//    DMR(String text, String text0, String text1, String text2, String text3, String text4, String genre, int id) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
    private void ajouterFicheExamen(FicheExamen fiche) {
        fichesExamen.add(fiche);
    }

    /**
     * @return the patient
     */
    public FichePatient getPatient() {
        return this.patient;
    }

    /**
     * @param patient the patient to set
     */
    public void setPatient(FichePatient patient) {
        this.patient = patient;
    }

    

}
